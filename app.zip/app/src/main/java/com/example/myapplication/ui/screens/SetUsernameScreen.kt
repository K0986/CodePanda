package com.example.myapplication.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.*
import com.example.myapplication.viewmodel.UserProgressViewModel

@Composable
fun SetUsernameScreen(
    progressViewModel: UserProgressViewModel,
    onDone: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    // Pulsing emoji animation
    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 0.9f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "scale"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepSpace, SpaceDark, SurfaceDark))),
        contentAlignment = Alignment.Center
    ) {
        // Purple glow
        Box(
            modifier = Modifier
                .size(350.dp)
                .align(Alignment.Center)
                .background(Brush.radialGradient(listOf(ElectricViolet.copy(0.18f), Color.Transparent)))
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Animated hero icon
            Box(
                modifier = Modifier
                    .scale(scale)
                    .size(100.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.radialGradient(listOf(VioletLight, ElectricViolet))),
                contentAlignment = Alignment.Center
            ) {
                Text("🧑‍💻", fontSize = 52.sp)
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "Choose your Hero name!",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 24.sp,
                color = TextPrimary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "This is how other learners will see you on the leaderboard 🏆",
                fontSize = 14.sp,
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(36.dp))

            OutlinedTextField(
                value = username,
                onValueChange = { username = it.take(20); error = null },
                label = { Text("Username (e.g. PythonNinja)") },
                leadingIcon = { Icon(Icons.Default.Person, null, tint = ElectricViolet) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricViolet,
                    unfocusedBorderColor = SurfaceVariantDark,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    cursorColor = ElectricViolet,
                    focusedContainerColor = SurfaceDark.copy(0.5f),
                    unfocusedContainerColor = SurfaceDark.copy(0.3f),
                    focusedLabelColor = ElectricViolet,
                    unfocusedLabelColor = TextMuted
                ),
                supportingText = {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        if (error != null) Text(error!!, color = HeartRed, fontSize = 12.sp)
                        else Text("", Modifier.weight(1f))
                        Text("${username.length}/20", color = TextMuted, fontSize = 12.sp)
                    }
                }
            )

            Spacer(Modifier.height(28.dp))

            // Confirm button
            Button(
                onClick = {
                    when {
                        username.trim().length < 3 -> error = "Must be at least 3 characters"
                        username.trim().contains(" ") -> error = "No spaces allowed"
                        else -> {
                            progressViewModel.setUsername(username.trim())
                            onDone()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(listOf(ElectricViolet, NeonCyan)),
                            RoundedCornerShape(16.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Let's Go! 🚀", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                }
            }

            Spacer(Modifier.height(16.dp))

            TextButton(onClick = {
                // Skip — use email prefix as default
                progressViewModel.setUsername(username.ifBlank { "Hero" })
                onDone()
            }) {
                Text("Skip for now", color = TextMuted, fontSize = 14.sp)
            }
        }
    }
}
