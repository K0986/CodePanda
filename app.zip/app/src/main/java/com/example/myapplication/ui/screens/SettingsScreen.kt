package com.example.myapplication.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.CorrectGreen
import com.example.myapplication.ui.theme.DeepSpace
import com.example.myapplication.ui.theme.ElectricViolet
import com.example.myapplication.ui.theme.HeartRed
import com.example.myapplication.ui.theme.SurfaceDark
import com.example.myapplication.ui.theme.SurfaceVariantDark
import com.example.myapplication.ui.theme.TextMuted
import com.example.myapplication.ui.theme.TextPrimary
import com.example.myapplication.ui.theme.TextSecondary
import com.example.myapplication.viewmodel.UserProgressViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    progressViewModel: UserProgressViewModel,
    onBack: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val settings = remember {
        context.getSharedPreferences("python_hero_settings", Context.MODE_PRIVATE)
    }
    var notifications by rememberSaveable { mutableStateOf(settings.getBoolean("notifications", true)) }
    var animations by rememberSaveable { mutableStateOf(settings.getBoolean("animations", true)) }
    var showResetDialog by rememberSaveable { mutableStateOf(false) }

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = TextPrimary, fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepSpace)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDone, null, tint = CorrectGreen)
                    Spacer(Modifier.padding(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Realtime sync", color = TextPrimary, fontWeight = FontWeight.Bold)
                        Text("Progress synced to Firebase", color = CorrectGreen, fontSize = 12.sp)
                    }
                }
            }
            SettingsToggle(
                icon = Icons.Default.Notifications,
                title = "Learning reminders",
                description = "Keep daily practice notifications enabled.",
                checked = notifications,
                onCheckedChange = {
                    notifications = it
                    settings.edit().putBoolean("notifications", it).apply()
                }
            )
            SettingsToggle(
                icon = Icons.Default.PlayCircle,
                title = "Motion and animations",
                description = "Use transitions and animated progress feedback.",
                checked = animations,
                onCheckedChange = {
                    animations = it
                    settings.edit().putBoolean("animations", it).apply()
                }
            )
            Spacer(Modifier.height(4.dp))
            Text("Account", color = TextSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            OutlinedButton(
                onClick = { showResetDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = HeartRed)
            ) {
                Icon(Icons.Default.DeleteSweep, null)
                Spacer(Modifier.padding(4.dp))
                Text("Clear local cache")
            }
            Button(
                onClick = onSignOut,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = HeartRed.copy(alpha = 0.9f))
            ) {
                Icon(Icons.Default.Logout, null)
                Spacer(Modifier.padding(4.dp))
                Text("Sign out", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text("Python Hero • v1.0", color = TextMuted, fontSize = 12.sp)
            Text(
                "Your learning progress is stored locally first and synced securely when you are signed in.",
                color = TextMuted,
                fontSize = 12.sp
            )
        }
    }

    if (showResetDialog) {
        AlertDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text("Clear local cache?") },
            text = { Text("This removes only this device’s cached copy. Your synced account progress stays in the cloud.") },
            confirmButton = {
                Button(
                    onClick = {
                        settings.edit().clear().apply()
                        progressViewModel.clearLocalCache()
                        showResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeartRed)
                ) { Text("Clear") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showResetDialog = false }) { Text("Cancel") }
            },
            containerColor = SurfaceDark,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary
        )
    }
}

@Composable
private fun SettingsToggle(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceVariantDark),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = ElectricViolet)
            Spacer(Modifier.padding(6.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold)
                Text(description, color = TextMuted, fontSize = 12.sp)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}