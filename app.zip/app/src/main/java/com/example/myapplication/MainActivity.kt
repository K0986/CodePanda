package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.model.Lesson
import com.example.myapplication.ui.screens.*
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.example.myapplication.viewmodel.UserProgressViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainNavigation()
            }
        }
    }
}

@Composable
fun MainNavigation() {
    val navController = rememberNavController()
    val progressViewModel: UserProgressViewModel = viewModel()
    val authViewModel: com.example.myapplication.viewmodel.AuthViewModel = viewModel()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var selectedCourseId by remember { mutableStateOf("python") }

    AppDrawer(
        drawerState = drawerState,
        progressViewModel = progressViewModel,
        onNavigate = { route ->
            scope.launch { drawerState.close() }
            when (route) {
                "home" -> navController.navigate("home") { launchSingleTop = true }
                "leaderboard" -> navController.navigate("leaderboard")
                "search" -> navController.navigate("search")
                "profile" -> navController.navigate("profile")
                "courses" -> navController.navigate("my_courses")
                "code" -> navController.navigate("compiler")
                "settings" -> navController.navigate("settings")
                "logout" -> {
                    progressViewModel.onUserLoggedOut()
                    authViewModel.logout()
                    navController.navigate("login") { popUpTo(0) }
                }
                else -> {}
            }
        }
    ) {
        NavHost(navController = navController, startDestination = "splash") {

            composable("splash") {
                SplashScreen(onNavigate = {
                    val authState = authViewModel.authState.value
                    if (authState is com.example.myapplication.viewmodel.AuthState.Success) {
                        navController.navigate("home") { popUpTo("splash") { inclusive = true } }
                    } else {
                        navController.navigate("login") { popUpTo("splash") { inclusive = true } }
                    }
                })
            }

            composable("login") {
                com.example.myapplication.ui.screens.LoginScreen(
                    authViewModel = authViewModel,
                    onNavigateToSignup = { navController.navigate("signup") },
                    onLoginSuccess = {
                        progressViewModel.onUserLoggedIn()
                        navController.navigate("home") { popUpTo("login") { inclusive = true } }
                    }
                )
            }

            composable("signup") {
                com.example.myapplication.ui.screens.SignupScreen(
                    authViewModel = authViewModel,
                    onNavigateToLogin = { navController.navigate("login") { popUpTo("signup") { inclusive = true } } },
                    onSignupSuccess = {
                        progressViewModel.onUserLoggedIn()
                        // New users go to username setup first
                        navController.navigate("set_username") { popUpTo("signup") { inclusive = true } }
                    }
                )
            }

            composable("set_username") {
                com.example.myapplication.ui.screens.SetUsernameScreen(
                    progressViewModel = progressViewModel,
                    onDone = {
                        navController.navigate("home") { popUpTo("set_username") { inclusive = true } }
                    }
                )
            }

            composable("home") {
                com.example.myapplication.ui.screens.HomeScreen(
                    onCourseClick = { course ->
                        selectedCourseId = course.id
                        navController.navigate("course_detail")
                    },
                    onMenuClick = { scope.launch { drawerState.open() } },
                    onSearchClick = { navController.navigate("search") },
                    progressViewModel = progressViewModel,
                    onContinueLearning = { courseId ->
                        selectedCourseId = courseId
                        navController.navigate("course_detail")
                    },
                    onBottomNavSelected = { tab ->
                        when (tab) {
                            NavTab.Home -> Unit
                            NavTab.Courses -> navController.navigate("my_courses") {
                                launchSingleTop = true
                            }
                            NavTab.Ranks -> navController.navigate("leaderboard") {
                                launchSingleTop = true
                            }
                            NavTab.Code -> navController.navigate("compiler") {
                                launchSingleTop = true
                            }
                        }
                    }
                )
            }

            composable("my_courses") {
                val lastLessonId by progressViewModel.lastActiveLessonId.collectAsState()
                MyCoursesScreen(
                    progressViewModel = progressViewModel,
                    onCourseClick = { course ->
                        selectedCourseId = course.id
                        navController.navigate("course_detail")
                    },
                    onResumeCourse = { course ->
                        selectedCourseId = course.id
                        val lessons = course.units.flatMap { it.lessons }
                        val lastIndex = lessons.indexOfFirst { it.id == lastLessonId }
                        selectedLesson = lessons
                            .drop((lastIndex + 1).coerceAtLeast(0))
                            .firstOrNull { it.id !in progressViewModel.progress.value.completedLessonIds }
                            ?: lessons.firstOrNull { it.id !in progressViewModel.progress.value.completedLessonIds }
                            ?: lessons.getOrNull(lastIndex.coerceAtLeast(0))
                        navController.navigate(if (selectedLesson != null) "lesson" else "course_detail")
                    },
                    onBrowseCourses = { navController.navigate("home") },
                    onBack = { navController.popBackStack() }
                )
            }

            composable("profile") {
                com.example.myapplication.ui.screens.ProfileScreen(
                    progressViewModel = progressViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("settings") {
                SettingsScreen(
                    progressViewModel = progressViewModel,
                    onBack = { navController.popBackStack() },
                    onSignOut = {
                        progressViewModel.onUserLoggedOut()
                        authViewModel.logout()
                        navController.navigate("login") { popUpTo(0) }
                    }
                )
            }

            composable("course_detail") {
                val course = AllCoursesData.findCourseById(selectedCourseId)
                    ?: AllCoursesData.python
                val coursesProgress by progressViewModel.coursesProgress.collectAsState()
                val userProgress by progressViewModel.progress.collectAsState()
                val courseWithProgress = course.copy(
                    progress = maxOf(course.progress, coursesProgress[course.id] ?: 0f)
                )
                CourseDetailScreen(
                    course = courseWithProgress,
                    completedLessonIds = userProgress.completedLessonIds,
                    onBack = { navController.popBackStack() },
                    onLessonSelect = { lesson ->
                        selectedLesson = lesson
                        navController.navigate("lesson")
                    }
                )
            }

            composable("lesson") {
                selectedLesson?.let { lesson ->
                    LessonScreen(
                        lesson = lesson,
                        onExit = { navController.popBackStack() },
                        onComplete = {
                            val course = AllCoursesData.findCourseById(selectedCourseId)
                                ?: AllCoursesData.python
                            val courseLessons = course.units.flatMap { it.lessons }
                            val completedCount = courseLessons.count {
                                it.id in progressViewModel.progress.value.completedLessonIds
                            }
                            val fraction = completedCount.toFloat() /
                                courseLessons.size.coerceAtLeast(1).toFloat()
                            progressViewModel.updateCourseProgress(
                                courseId = selectedCourseId,
                                progressFraction = fraction,
                                lastLessonId = lesson.id
                            )
                            navController.navigate("success") { launchSingleTop = true }
                        },
                        progressViewModel = progressViewModel
                    )
                }
            }

            composable("success") {
                SuccessScreen(onContinue = {
                    navController.popBackStack("course_detail", inclusive = false)
                })
            }

            composable("compiler") {
                CompilerScreen(
                    courseId = selectedCourseId,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("cheatsheet/{title}") { backStackEntry ->
                val title = backStackEntry.arguments?.getString("title") ?: "Cheat Sheet"
                CheatSheetScreen(
                    courseId = selectedCourseId,
                    courseTitle = title,
                    onBack = { navController.popBackStack() }
                )
            }

            composable("leaderboard") {
                val progress by progressViewModel.progress.collectAsState()
                LeaderboardScreen(currentXp = progress.xp)
            }

            composable("search") {
                SearchScreen(
                    onCourseClick = { course ->
                        selectedCourseId = course.id
                        navController.navigate("course_detail")
                    },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
