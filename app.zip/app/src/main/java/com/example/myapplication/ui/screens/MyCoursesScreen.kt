package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.model.Course
import com.example.myapplication.ui.components.CourseLogo
import com.example.myapplication.ui.theme.DeepSpace
import com.example.myapplication.ui.theme.ElectricViolet
import com.example.myapplication.ui.theme.SurfaceDark
import com.example.myapplication.ui.theme.SurfaceVariantDark
import com.example.myapplication.ui.theme.TextMuted
import com.example.myapplication.ui.theme.TextPrimary
import com.example.myapplication.ui.theme.TextSecondary
import com.example.myapplication.viewmodel.UserProgressViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCoursesScreen(
    progressViewModel: UserProgressViewModel,
    onCourseClick: (Course) -> Unit,
    onResumeCourse: (Course) -> Unit = onCourseClick,
    onBrowseCourses: () -> Unit,
    onBack: () -> Unit
) {
    val coursesProgress by progressViewModel.coursesProgress.collectAsState()
    val startedCourses = AllCoursesData.allCourses
        .filter { (coursesProgress[it.id] ?: 0f) > 0f }
        .map { course ->
            course.copy(progress = coursesProgress[course.id] ?: course.progress)
        }
        .sortedByDescending { coursesProgress[it.id] ?: 0f }

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            TopAppBar(
                title = { Text("My Courses", color = TextPrimary, fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepSpace)
            )
        }
    ) { padding ->
        if (startedCourses.isEmpty()) {
            EmptyCourses(
                modifier = Modifier.padding(padding),
                onBrowseCourses = onBrowseCourses
            )
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        "Pick up exactly where you stopped",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                }
                items(startedCourses, key = { it.id }) { course ->
                    MyCourseCard(course = course, onClick = { onResumeCourse(course) })
                }
            }
        }
    }
}

@Composable
private fun MyCourseCard(course: Course, onClick: () -> Unit) {
    val progress = course.progress.coerceIn(0f, 1f)
    val percent = (progress * 100).toInt()
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceVariantDark)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(course.gradientStart), Color(course.gradientEnd))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                CourseLogo(courseId = course.id, size = 46.dp)
            }
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(course.title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    if (progress >= 1f) "Completed" else "$percent% complete",
                    color = if (progress >= 1f) Color(0xFF4ADE80) else TextMuted,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = ElectricViolet,
                    trackColor = SurfaceVariantDark
                )
            }
            Spacer(Modifier.size(10.dp))
            Icon(Icons.Default.PlayArrow, "Resume", tint = ElectricViolet)
        }
    }
}

@Composable
private fun EmptyCourses(modifier: Modifier = Modifier, onBrowseCourses: () -> Unit) {
    Column(
        modifier = modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🎯", fontSize = 58.sp)
        Spacer(Modifier.height(16.dp))
        Text("Your learning path starts here", color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("Choose a course and we’ll save every lesson so you can resume on any device.", color = TextSecondary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onBrowseCourses,
            colors = ButtonDefaults.buttonColors(containerColor = ElectricViolet),
            shape = RoundedCornerShape(14.dp)
        ) { Text("Browse courses", fontWeight = FontWeight.Bold) }
    }
}