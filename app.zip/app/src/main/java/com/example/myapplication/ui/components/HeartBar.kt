package com.example.myapplication.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HeartBar(
    heartsLeft: Int,
    maxHearts: Int = 5,
    heartLost: Boolean = false,
    onHeartLostAnimationDone: () -> Unit = {}
) {
    val shakeAnim = remember { Animatable(0f) }

    LaunchedEffect(heartLost) {
        if (heartLost) {
            // Shake animation
            repeat(3) {
                shakeAnim.animateTo(12f, animationSpec = tween(60))
                shakeAnim.animateTo(-12f, animationSpec = tween(60))
            }
            shakeAnim.animateTo(0f, animationSpec = tween(60))
            onHeartLostAnimationDone()
        }
    }

    Row(modifier = Modifier.graphicsLayer { translationX = shakeAnim.value }) {
        repeat(maxHearts) { index ->
            val isFilled = index < heartsLeft
            Text(
                text = if (isFilled) "❤️" else "🖤",
                fontSize = 18.sp,
                modifier = Modifier
                    .padding(end = 2.dp)
                    .alpha(if (isFilled) 1f else 0.4f)
            )
        }
    }
}
