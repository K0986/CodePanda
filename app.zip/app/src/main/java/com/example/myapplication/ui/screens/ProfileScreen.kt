package com.example.myapplication.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.myapplication.ui.theme.*
import com.example.myapplication.viewmodel.PhotoUploadState
import com.example.myapplication.viewmodel.SyncState
import com.example.myapplication.viewmodel.UserProgressViewModel
import com.google.firebase.auth.FirebaseAuth

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    progressViewModel: UserProgressViewModel,
    onBack: () -> Unit
) {
    val progress by progressViewModel.progress.collectAsState()
    val username by progressViewModel.username.collectAsState()
    val photoUrl by progressViewModel.photoUrl.collectAsState()
    val uploadState by progressViewModel.photoUploadState.collectAsState()
    val syncState by progressViewModel.syncState.collectAsState()
    val coursesProgress by progressViewModel.coursesProgress.collectAsState()

    val firebaseUser = FirebaseAuth.getInstance().currentUser
    val context = LocalContext.current
    var editingUsername by remember { mutableStateOf(false) }
    var newUsername by remember { mutableStateOf(username) }
    var usernameError by remember { mutableStateOf<String?>(null) }

    // Image picker launcher
    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            // OpenDocument grants a durable read permission, so the upload
            // still works after the picker activity has been recreated.
            try {
                context.contentResolver.takePersistableUriPermission(
                    it,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some providers do not support persistable permissions. The
                // current callback still has access and can upload normally.
            }
            progressViewModel.setLocalPhotoPreview(it)
            progressViewModel.uploadProfilePhoto(it)
        }
    }

    // Pulsing avatar animation
    val pulse = rememberInfiniteTransition(label = "pulse")
    val avatarScale by pulse.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "avatarScale"
    )

    // Stats
    val startedCourses = coursesProgress.count { it.value > 0f }
    val completedCourses = coursesProgress.count { it.value >= 1f }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Profile", fontWeight = FontWeight.ExtraBold, color = TextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DeepSpace)
            )
        },
        containerColor = DeepSpace
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ── Header gradient ───────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(
                        Brush.verticalGradient(listOf(ElectricViolet.copy(0.4f), DeepSpace))
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Avatar
                Box(
                    modifier = Modifier.scale(avatarScale),
                    contentAlignment = Alignment.BottomEnd
                ) {
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(VioletLight, ElectricViolet)))
                            .clickable { imagePicker.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        if (photoUrl.isNotBlank()) {
                            AsyncImage(
                                model = photoUrl,
                                contentDescription = "Profile photo",
                                modifier = Modifier.fillMaxSize().clip(CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                username.firstOrNull()?.uppercaseChar()?.toString() ?: "🧑‍💻",
                                fontSize = if (username.isNotBlank()) 42.sp else 36.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                        }
                    }
                    // Camera badge
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(NeonCyan)
                            .clickable { imagePicker.launch(arrayOf("image/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CameraAlt, null, tint = Color.White,
                            modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Upload progress
            if (uploadState is PhotoUploadState.Uploading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = NeonCyan, trackColor = SurfaceVariantDark
                )
            }
            when (val state = uploadState) {
                is PhotoUploadState.Error -> Text(
                    text = state.message,
                    color = HeartRed,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
                )
                is PhotoUploadState.Success -> Text(
                    text = "Profile photo synced",
                    color = CorrectGreen,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
                )
                else -> Unit
            }

            Spacer(Modifier.height(16.dp))

            // ── Username section ──────────────────────────────────────────────
            if (editingUsername) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newUsername,
                        onValueChange = { newUsername = it.take(20); usernameError = null },
                        label = { Text("Username") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        singleLine = true,
                        isError = usernameError != null,
                        supportingText = { usernameError?.let { Text(it, color = HeartRed) } },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricViolet,
                            unfocusedBorderColor = SurfaceVariantDark,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricViolet,
                            focusedLabelColor = ElectricViolet,
                            unfocusedLabelColor = TextMuted
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = {
                        when {
                            newUsername.trim().length < 3 -> usernameError = "Min 3 chars"
                            newUsername.trim().contains(" ") -> usernameError = "No spaces"
                            else -> {
                                progressViewModel.setUsername(newUsername.trim())
                                editingUsername = false
                            }
                        }
                    }) {
                        Icon(Icons.Default.Check, null, tint = CorrectGreen)
                    }
                    IconButton(onClick = { editingUsername = false; newUsername = username }) {
                        Icon(Icons.Default.Close, null, tint = HeartRed)
                    }
                }
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        if (username.isNotBlank()) username else "Set a username",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        color = if (username.isNotBlank()) TextPrimary else TextMuted
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(onClick = { editingUsername = true; newUsername = username }) {
                        Icon(Icons.Default.Edit, null, tint = ElectricViolet, modifier = Modifier.size(18.dp))
                    }
                }
                Text(
                    firebaseUser?.email ?: "",
                    fontSize = 13.sp, color = TextMuted
                )
                Spacer(Modifier.height(6.dp))
                val syncColor = when (syncState) {
                    SyncState.Synced -> CorrectGreen
                    SyncState.Syncing -> XpGold
                    SyncState.Error -> HeartRed
                    SyncState.Idle -> TextMuted
                }
                val syncLabel = when (syncState) {
                    SyncState.Synced -> "Synced in real time"
                    SyncState.Syncing -> "Syncing changes…"
                    SyncState.Error -> "Sync will retry automatically"
                    SyncState.Idle -> "Local progress"
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(syncColor)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(syncLabel, fontSize = 11.sp, color = syncColor)
                }
            }

            Spacer(Modifier.height(24.dp))

            // ── Stats cards ───────────────────────────────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ProfileStatCard("⚡ XP", "${progress.xp}", Modifier.weight(1f))
                ProfileStatCard("🏆 Level", "${progress.level}", Modifier.weight(1f))
                ProfileStatCard("🔥 Streak", "${progress.streak}d", Modifier.weight(1f))
                ProfileStatCard("❤️ Hearts", "${progress.heartsLeft}", Modifier.weight(1f))
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ProfileStatCard("📚 Lessons", "${progress.totalLessonsCompleted}", Modifier.weight(1f))
                ProfileStatCard("🎯 Courses", "$startedCourses started", Modifier.weight(1f))
                ProfileStatCard("✅ Done", "$completedCourses complete", Modifier.weight(1f))
            }

            Spacer(Modifier.height(20.dp))

            // ── XP Progress to next level ─────────────────────────────────────
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Text("Level ${progress.level}", fontWeight = FontWeight.ExtraBold, color = TextPrimary)
                        Text("${progress.xp} / ${progress.level * 100} XP", fontSize = 12.sp, color = XpGold)
                    }
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress.levelProgress },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = XpGold, trackColor = SurfaceVariantDark
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${progress.level * 100 - progress.xp} XP to Level ${progress.level + 1}",
                        fontSize = 11.sp, color = TextMuted
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // ── Courses progress ──────────────────────────────────────────────
            if (coursesProgress.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Course Progress", fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary, fontSize = 15.sp)
                        Spacer(Modifier.height(12.dp))
                        coursesProgress.filter { it.value > 0f }.forEach { (courseId, fraction) ->
                            CourseProgressRow(courseId, fraction)
                            Spacer(Modifier.height(10.dp))
                        }
                    }
                }
            }

            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ProfileStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 10.sp, color = TextMuted, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp,
                color = TextPrimary, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun CourseProgressRow(courseId: String, fraction: Float) {
    val name = courseId.replace("_", " ").replaceFirstChar { it.uppercase() }
    val pct = (fraction * 100).toInt()
    Column {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text(name, fontSize = 13.sp, color = TextSecondary)
            Text("$pct%", fontSize = 13.sp, color = ElectricViolet, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = ElectricViolet, trackColor = SurfaceVariantDark
        )
    }
}
