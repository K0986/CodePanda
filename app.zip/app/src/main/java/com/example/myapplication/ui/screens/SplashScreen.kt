package com.example.myapplication.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

data class Particle(
    val x: Float,
    val startY: Float,
    val size: Float,
    val speed: Float,
    val color: Color,
    val phaseOffset: Float
)

@Composable
fun SplashScreen(onNavigate: () -> Unit) {
    val particles = remember {
        List(20) {
            Particle(
                x = Random.nextFloat(),
                startY = Random.nextFloat() * 0.8f + 0.2f,
                size = Random.nextFloat() * 8f + 4f,
                speed = Random.nextFloat() * 0.3f + 0.15f,
                color = listOf(
                    Color(0xFF7C3AED), Color(0xFF06B6D4),
                    Color(0xFFF59E0B), Color(0xFF10B981)
                ).random(),
                phaseOffset = Random.nextFloat() * 6.28f
            )
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "splash")

    val particleTime by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "particles"
    )

    // Logo scale pulse
    val logoScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            tween(1000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "logoScale"
    )

    // Entry animations
    var visible by remember { mutableStateOf(false) }
    val alphaAnim by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(800),
        label = "alpha"
    )
    val slideAnim by animateFloatAsState(
        targetValue = if (visible) 0f else 60f,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "slide"
    )

    LaunchedEffect(Unit) {
        visible = true
        delay(2500)
        onNavigate()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0D0A1A), Color(0xFF1A1035), Color(0xFF0D0A1A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Floating particles drawn on Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            particles.forEach { particle ->
                val t = ((particleTime + particle.phaseOffset / 6.28f) % 1f)
                val currentY = particle.startY - t * particle.speed
                if (currentY < 0f || currentY > 1f) return@forEach

                val wobble = sin(t * 6.28f * 2 + particle.phaseOffset) * 0.02f
                val cx = (particle.x + wobble) * size.width
                val cy = currentY * size.height
                val alpha = if (t < 0.1f) t / 0.1f else if (t > 0.8f) (1f - t) / 0.2f else 1f

                drawCircle(
                    color = particle.color.copy(alpha = alpha * 0.7f),
                    radius = particle.size,
                    center = Offset(cx, cy)
                )
            }
        }

        // Glow blob behind logo
        Box(
            modifier = Modifier
                .size(240.dp)
                .blur(60.dp)
                .clip(CircleShape)
                .background(Color(0xFF7C3AED).copy(alpha = 0.4f))
        )

        Column(
            modifier = Modifier
                .alpha(alphaAnim)
                .graphicsLayer { translationY = slideAnim },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Box(
                modifier = Modifier
                    .scale(logoScale)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFF9F67F0), Color(0xFF4F46E5))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🐍", fontSize = 60.sp)
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = "Python Hero",
                fontSize = 38.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = (-1).sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Level up your coding skills ⚡",
                fontSize = 16.sp,
                color = Color(0xFF94A3B8),
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Loading dots
            LoadingDots()
        }
    }
}

@Composable
fun LoadingDots() {
    val infiniteTransition = rememberInfiniteTransition(label = "dots")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(3) { index ->
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.5f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = keyframes {
                        durationMillis = 900
                        0.5f at 0
                        1f at 200
                        0.5f at 400
                        0.5f at 900
                    },
                    initialStartOffset = StartOffset(index * 150)
                ),
                label = "dot$index"
            )
            Box(
                modifier = Modifier
                    .scale(scale)
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF7C3AED))
            )
        }
    }
}
