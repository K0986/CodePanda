package com.example.myapplication.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.ai.GeminiTutor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LessonViewModel(application: Application) : AndroidViewModel(application) {
    private val tutor = GeminiTutor()

    private val _aiResponse = MutableStateFlow<String?>(null)
    val aiResponse: StateFlow<String?> = _aiResponse

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _codeOutput = MutableStateFlow<String?>(null)
    val codeOutput: StateFlow<String?> = _codeOutput

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning

    fun askAI(topic: String, question: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _aiResponse.value = null
            Log.d("LessonViewModel", "Asking AI: topic=$topic")
            val result = tutor.getExplanation(topic, question)
            Log.d("LessonViewModel", "AI response: ${result?.take(50)}")
            _aiResponse.value = result
            _isLoading.value = false
        }
    }

    fun runCode(language: String, code: String) {
        viewModelScope.launch {
            _isRunning.value = true
            _codeOutput.value = null
            Log.d("LessonViewModel", "Running $language code: ${code.take(50)}")
            val result = tutor.runCode(language, code)
            Log.d("LessonViewModel", "Code output: ${result.take(50)}")
            _codeOutput.value = result
            _isRunning.value = false
        }
    }

    fun clearAIResponse() {
        _aiResponse.value = null
    }

    fun clearCodeOutput() {
        _codeOutput.value = null
    }
}
