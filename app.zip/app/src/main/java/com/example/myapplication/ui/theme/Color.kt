package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

// === Background & Surface ===
val DeepSpace = Color(0xFF0D0A1A)
val SpaceDark = Color(0xFF1A1035)
val SurfaceDark = Color(0xFF221A40)
val SurfaceVariantDark = Color(0xFF2C234F)
val CardDark = Color(0xFF1E1640)

// === Brand / Primary ===
val ElectricViolet = Color(0xFF7C3AED)
val VioletLight = Color(0xFF9F67F0)
val VioletGlow = Color(0xFF7C3AED).copy(alpha = 0.4f)

// === Accent / Secondary ===
val NeonCyan = Color(0xFF06B6D4)
val CyanGlow = Color(0xFF06B6D4).copy(alpha = 0.3f)

// === Gamification ===
val XpGold = Color(0xFFF59E0B)
val XpGoldGlow = Color(0xFFF59E0B).copy(alpha = 0.4f)
val StreakOrange = Color(0xFFFF6B35)
val HeartRed = Color(0xFFEF4444)
val HeartRedDim = Color(0xFF7F2020)
val LevelTeal = Color(0xFF10B981)

// === Feedback ===
val CorrectGreen = Color(0xFF22C55E)
val CorrectGreenSurface = Color(0xFF14532D)
val WrongRed = Color(0xFFEF4444)
val WrongRedSurface = Color(0xFF7F1D1D)

// === Text ===
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// === Course Theme Colors ===
val PythonTeal = Color(0xFF0D9488)
val PythonTealDark = Color(0xFF0F766E)
val HtmlOrange = Color(0xFFEA580C)
val HtmlOrangeDark = Color(0xFFC2410C)
val CBlue = Color(0xFF2563EB)
val CBlueDark = Color(0xFF1D4ED8)

// Legacy (keep for Material compat)
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)