package com.example.myapplication.data

import com.example.myapplication.model.*

object PythonCourseData {
    val pythonCourse = Course(
        id = "python_basics",
        title = "Python",
        description = "Master the fundamentals of Python programming with interactive lessons and AI guidance.",
        trending = true,
        progress = 0f,
        gradientStart = 0xFF0D9488,
        gradientEnd = 0xFF0891B2,
        tag = "BEGINNER",
        units = listOf(
            CourseUnit(
                id = "unit_1_intro",
                title = "🐍 Unit 1: Python Fundamentals",
                lessons = listOf(
                    Lesson(
                        id = "lesson_1_what_is_python",
                        title = "What is Python?",
                        type = LessonType.CONTENT,
                        durationMinutes = 5,
                        xpReward = 10,
                        isCompleted = true,
                        content = listOf(
                            LessonContent.Text(
                                "What is a Program? 🤔",
                                isHeader = true
                            ),
                            LessonContent.Text(
                                "A program is a set of instructions that tells the computer what to do. " +
                                "Think of it like a recipe — step by step instructions to achieve a result!"
                            ),
                            LessonContent.Text(
                                "Python is one of the world's most popular programming languages. " +
                                "It was created by Guido van Rossum and released in 1991.",
                                isHeader = false
                            ),
                            LessonContent.CodeSnippet(
                                code = "print(\"Hello, Python Hero! 🐍\")",
                                language = "python",
                                caption = "Your very first Python program!"
                            ),
                            LessonContent.Text("Python is used for:\n• 🌐 Web development\n• 🤖 AI & Machine Learning\n• 📊 Data Science\n• 🎮 Game development"),
                            LessonContent.Quiz(
                                question = "Which of these could have involved Python programs?",
                                options = listOf(
                                    "Sending a Rover to Mars 🚀",
                                    "Netflix recommendations 🎬",
                                    "Google Search algorithms 🔍",
                                    "All of the above! 🌟"
                                ),
                                correctAnswerIndex = 3,
                                explanation = "Python powers everything from NASA's Mars missions to Netflix recommendations and Google's algorithms!"
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_2_variables",
                        title = "Variables & Data",
                        type = LessonType.CONTENT,
                        durationMinutes = 7,
                        xpReward = 15,
                        content = listOf(
                            LessonContent.Text("Storing Data in Python 📦", isHeader = true),
                            LessonContent.Text(
                                "Variables are containers for storing data values. " +
                                "Think of them like labeled boxes where you can store information."
                            ),
                            LessonContent.CodeSnippet(
                                code = "# Creating variables\nname = \"Python Hero\"\nage = 16\nscore = 9.5\n\nprint(name)  # Python Hero",
                                caption = "Variables store different types of data"
                            ),
                            LessonContent.Text(
                                "Python has 3 main data types you'll use all the time:\n" +
                                "• 📝 String — text: \"Hello\"\n" +
                                "• 🔢 Integer — whole number: 42\n" +
                                "• 💧 Float — decimal: 3.14"
                            ),
                            LessonContent.Quiz(
                                question = "How do you store the number 5 in a variable named 'x'?",
                                options = listOf("x = 5", "int x = 5", "var x = 5", "x := 5"),
                                correctAnswerIndex = 0,
                                explanation = "In Python, no type declaration needed! Just use = to assign a value directly. 🎉"
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_3_input_output",
                        title = "Input & Output",
                        type = LessonType.CONTENT,
                        durationMinutes = 8,
                        xpReward = 15,
                        content = listOf(
                            LessonContent.Text("Talking to Your Program 💬", isHeader = true),
                            LessonContent.Text(
                                "Programs talk to users using input() and output (print()). " +
                                "This is how your program becomes interactive!"
                            ),
                            LessonContent.CodeSnippet(
                                code = "# Getting user input\nname = input(\"What's your name? \")\nprint(\"Hello,\", name, \"! You're awesome! 🌟\")",
                                caption = "Making programs interactive with input()"
                            ),
                            LessonContent.CodeSnippet(
                                code = "# String formatting (f-strings)\nage = 16\nprint(f\"You are {age} years old\")\nprint(f\"In 10 years you'll be {age + 10}!\")",
                                caption = "f-strings make text formatting easy"
                            ),
                            LessonContent.Quiz(
                                question = "What does the print() function do?",
                                options = listOf(
                                    "Prints a document 🖨️",
                                    "Displays output on screen 💻",
                                    "Takes input from user",
                                    "Creates a variable"
                                ),
                                correctAnswerIndex = 1,
                                explanation = "print() displays text/data on the screen. It's your program talking to the user! 💬"
                            )
                        )
                    )
                )
            ),
            CourseUnit(
                id = "unit_2_logic",
                title = "🧠 Unit 2: Making Decisions",
                lessons = listOf(
                    Lesson(
                        id = "lesson_4_conditionals",
                        title = "If/Else Conditions",
                        type = LessonType.CONTENT,
                        durationMinutes = 10,
                        xpReward = 20,
                        content = listOf(
                            LessonContent.Text("Making Decisions with If/Else 🚦", isHeader = true),
                            LessonContent.Text(
                                "Conditions let your program make decisions! " +
                                "Just like in real life — if it's raining, take an umbrella, else wear sunglasses. ☀️"
                            ),
                            LessonContent.CodeSnippet(
                                code = "score = 85\n\nif score >= 90:\n    print(\"Grade: A+ 🏆\")\nelif score >= 80:\n    print(\"Grade: B 🎉\")\nelse:\n    print(\"Keep practicing! 💪\")",
                                caption = "if/elif/else — Python's decision maker"
                            ),
                            LessonContent.Text(
                                "Comparison operators you'll use:\n" +
                                "• == (equals)\n• != (not equals)\n• > (greater than)\n• < (less than)\n• >= (greater or equal)\n• <= (less or equal)"
                            ),
                            LessonContent.Quiz(
                                question = "What will print if score = 95?",
                                options = listOf(
                                    "Grade: A+ 🏆",
                                    "Grade: B 🎉",
                                    "Keep practicing! 💪",
                                    "Nothing"
                                ),
                                correctAnswerIndex = 0,
                                explanation = "95 >= 90 is True, so the first branch executes: 'Grade: A+ 🏆'"
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_5_loops",
                        title = "Loops & Repetition",
                        type = LessonType.CONTENT,
                        durationMinutes = 12,
                        xpReward = 20,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Loops: Do It Again! 🔄", isHeader = true),
                            LessonContent.Text(
                                "Loops let you repeat code without writing it multiple times. " +
                                "Imagine telling your computer to print numbers 1-100. Without loops, you'd write 100 lines! 😱"
                            ),
                            LessonContent.CodeSnippet(
                                code = "# for loop — repeat a fixed number of times\nfor i in range(1, 6):\n    print(f\"⭐ Star {i}\")\n\n# Output:\n# ⭐ Star 1\n# ⭐ Star 2  ...",
                                caption = "for loops repeat for each item in a range"
                            ),
                            LessonContent.CodeSnippet(
                                code = "# while loop — repeat until a condition is False\ncount = 0\nwhile count < 3:\n    print(f\"Count: {count} 🚀\")\n    count += 1",
                                caption = "while loops keep going until condition is False"
                            ),
                            LessonContent.Quiz(
                                question = "How many times will this loop run?\nfor i in range(5):",
                                options = listOf("4 times", "5 times", "6 times", "Infinite times"),
                                correctAnswerIndex = 1,
                                explanation = "range(5) produces 0,1,2,3,4 — that's exactly 5 values! Python ranges start at 0 by default. 🎯"
                            )
                        )
                    )
                )
            ),
            CourseUnit(
                id = "unit_3_oop",
                title = "🏗️ Unit 3: Object-Oriented Python",
                lessons = listOf(
                    Lesson(
                        id = "lesson_oop_1",
                        title = "Classes and Objects",
                        type = LessonType.CONTENT,
                        durationMinutes = 15,
                        xpReward = 30,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Object-Oriented Programming (OOP)", isHeader = true),
                            LessonContent.Text("OOP allows us to group data and behavior together in a blueprint called a 'Class'. Things created from this blueprint are called 'Objects'."),
                            LessonContent.CodeSnippet(
                                code = "class Hero:\n    def __init__(self, name):\n        self.name = name\n        self.health = 100\n\nplayer = Hero(\"Kundan\")\nprint(player.name, player.health)",
                                language = "python"
                            ),
                            LessonContent.Quiz("What keyword defines a class?", listOf("def", "class", "object", "struct"), 1, "Correct! 'class' is used.")
                        )
                    ),
                    Lesson(
                        id = "lesson_oop_2",
                        title = "Methods and Self",
                        type = LessonType.CODE,
                        durationMinutes = 10,
                        xpReward = 30,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Teach Your Objects to Act 🧰", isHeader = true),
                            LessonContent.Text("Methods are functions that belong to a class. self is the object currently using the method — like saying 'my own score'."),
                            LessonContent.CodeSnippet(
                                "class Hero:\n    def __init__(self, name):\n        self.name = name\n        self.xp = 0\n\n    def earn_xp(self, amount):\n        self.xp += amount\n        return f\"{self.name} now has {self.xp} XP\"\n\nhero = Hero(\"Maya\")\nprint(hero.earn_xp(25))"
                            ),
                            LessonContent.Quiz(
                                "What does self refer to?",
                                listOf("The Python language", "The current object", "A parent class", "A loop"),
                                1,
                                "self is the current object instance."
                            )
                        )
                    )
                )
            ),
            CourseUnit(
                id = "unit_4_advanced",
                title = "⚡ Unit 4: Advanced Python",
                lessons = listOf(
                    Lesson(
                        id = "lesson_adv_1",
                        title = "Decorators and Generators",
                        type = LessonType.CONTENT,
                        durationMinutes = 20,
                        xpReward = 50,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Decorators 🎁", isHeader = true),
                            LessonContent.Text("Decorators wrap a function, modifying its behavior. They start with the @ symbol."),
                            LessonContent.CodeSnippet(
                                code = "def my_decorator(func):\n    def wrapper():\n        print(\"Before the function is called.\")\n        func()\n        print(\"After the function is called.\")\n    return wrapper\n\n@my_decorator\ndef say_whee():\n    print(\"Whee!\")\n\nsay_whee()",
                                language = "python"
                            )
                        )
                    )
                )
            ),
            CourseUnit(
                id = "unit_5_real_world",
                title = "🛠️ Unit 5: Build Real Programs",
                lessons = listOf(
                    Lesson(
                        id = "lesson_functions",
                        title = "Functions: Your Reusable Superpowers",
                        type = LessonType.CONTENT,
                        durationMinutes = 12,
                        xpReward = 25,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Functions: Write Once, Reuse Everywhere 🧩", isHeader = true),
                            LessonContent.Text("A function is like a recipe card. You give it ingredients (arguments), it does a job, and it can hand back a result. Functions keep real projects tidy."),
                            LessonContent.Animation("function_recipe"),
                            LessonContent.CodeSnippet(
                                "def make_sandwich(bread, filling):\n    return f\"{bread} sandwich with {filling}\"\n\nlunch = make_sandwich(\"toasted\", \"cheese\")\nprint(lunch)",
                                caption = "A function turns a repeated job into a tool"
                            ),
                            LessonContent.Quiz(
                                "What does return do?",
                                listOf("Repeats a loop", "Sends a result back", "Prints automatically", "Creates a class"),
                                1,
                                "return sends a value back to the code that called the function."
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_collections",
                        title = "Lists, Dictionaries & Sets",
                        type = LessonType.CONTENT,
                        durationMinutes = 14,
                        xpReward = 25,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Choose the Right Data Container 🧺", isHeader = true),
                            LessonContent.Text("A list is a shopping basket, a dictionary is a labeled cupboard, and a set is a guest list with no duplicates."),
                            LessonContent.Animation("collections"),
                            LessonContent.CodeSnippet(
                                "shopping = [\"apples\", \"milk\"]\nprofile = {\"name\": \"Maya\", \"xp\": 120}\ntags = {\"python\", \"coding\", \"python\"}\n\nshopping.append(\"bread\")\nprint(profile[\"name\"])\nprint(tags)  # duplicates disappear"
                            ),
                            LessonContent.Quiz(
                                "Which container stores key/value pairs?",
                                listOf("List", "Tuple", "Dictionary", "Set"),
                                2,
                                "Dictionaries map a key such as name to a value such as Maya."
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_errors",
                        title = "Errors & Defensive Code",
                        type = LessonType.CONTENT,
                        durationMinutes = 12,
                        xpReward = 25,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Make Your Program Helpful, Not Fragile 🛡️", isHeader = true),
                            LessonContent.Text("Users make unexpected choices. try/except lets your app recover gracefully instead of crashing when someone types letters where a number was expected."),
                            LessonContent.CodeSnippet(
                                "try:\n    age = int(input(\"Your age: \"))\n    print(f\"Next year: {age + 1}\")\nexcept ValueError:\n    print(\"Please enter a whole number.\")"
                            ),
                            LessonContent.Quiz(
                                "Which block handles a matching error?",
                                listOf("try", "except", "finally", "import"),
                                1,
                                "except runs when the code in try raises the error you name."
                            )
                        )
                    )
                )
            ),
            CourseUnit(
                id = "unit_6_data",
                title = "📊 Unit 6: Python for Data",
                lessons = listOf(
                    Lesson(
                        id = "lesson_files",
                        title = "Read and Write Files",
                        type = LessonType.CONTENT,
                        durationMinutes = 14,
                        xpReward = 30,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Give Your Program a Memory 📓", isHeader = true),
                            LessonContent.Text("Files let a program remember information after it closes: notes, scores, settings, and more. Always use with open so Python closes the file safely."),
                            LessonContent.CodeSnippet(
                                "with open(\"journal.txt\", \"w\") as journal:\n    journal.write(\"Today I learned Python!\\n\")\n\nwith open(\"journal.txt\") as journal:\n    print(journal.read())"
                            ),
                            LessonContent.Quiz(
                                "Why use with open(...)?",
                                listOf("It makes code faster", "It closes the file safely", "It encrypts text", "It creates a database"),
                                1,
                                "The with block handles cleanup even if something goes wrong."
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_modules",
                        title = "Modules & Useful Libraries",
                        type = LessonType.CONTENT,
                        durationMinutes = 15,
                        xpReward = 30,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Borrow Superpowers from Libraries 📚", isHeader = true),
                            LessonContent.Text("A module is a Python file full of useful code. import lets you reuse trusted tools instead of rebuilding everything."),
                            LessonContent.Animation("modules"),
                            LessonContent.CodeSnippet(
                                "import random\nfrom datetime import date\n\nprint(random.randint(1, 6))\nprint(date.today())"
                            ),
                            LessonContent.Quiz(
                                "What does import do?",
                                listOf("Deletes code", "Loads reusable code", "Starts a loop", "Formats a string"),
                                1,
                                "import makes names from another module available to your program."
                            )
                        )
                    ),
                    Lesson(
                        id = "lesson_project",
                        title = "Capstone: Personal Expense Tracker",
                        type = LessonType.CODE,
                        durationMinutes = 25,
                        xpReward = 50,
                        isLocked = false,
                        content = listOf(
                            LessonContent.Text("Build Something Useful 💳", isHeader = true),
                            LessonContent.Text("Combine variables, lists, functions, loops, and safe input to build a tiny expense tracker. Start small, test often, and improve it one feature at a time."),
                            LessonContent.CodeSnippet(
                                "expenses = []\n\ndef add_expense(name, amount):\n    expenses.append({\"name\": name, \"amount\": amount})\n\nadd_expense(\"Lunch\", 8.50)\nadd_expense(\"Bus\", 2.00)\nprint(sum(item[\"amount\"] for item in expenses))",
                                caption = "A small project that uses the skills you have learned"
                            ),
                            LessonContent.Quiz(
                                "What is the best first step for a larger project?",
                                listOf("Write everything at once", "Break it into small testable functions", "Skip testing", "Copy random code"),
                                1,
                                "Small, testable pieces make projects easier to understand and fix."
                            )
                        )
                    )
                )
            )
        )
    )

    val allCourses = listOf(
        pythonCourse,
        Course(
            id = "html_basics",
            title = "HTML & CSS",
            description = "Build beautiful websites from scratch.",
            progress = 0f,
            gradientStart = 0xFFEA580C,
            gradientEnd = 0xFFDC2626,
            tag = "WEB",
            trending = false,
            isNew = false
        ),
        Course(
            id = "c_programming",
            title = "C Programming",
            description = "Learn the language behind the operating systems.",
            progress = 0f,
            gradientStart = 0xFF2563EB,
            gradientEnd = 0xFF7C3AED,
            tag = "SYSTEMS",
            isNew = true
        ),
        Course(
            id = "javascript",
            title = "JavaScript",
            description = "Make websites interactive and dynamic.",
            progress = 0f,
            gradientStart = 0xFFF59E0B,
            gradientEnd = 0xFFEA580C,
            tag = "WEB",
            isNew = true
        )
    )
}
