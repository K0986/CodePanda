package com.example.myapplication.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.example.myapplication.ui.theme.*
import com.example.myapplication.viewmodel.UserProgressViewModel
import androidx.compose.ui.layout.ContentScale

@Composable
fun AppDrawer(
    drawerState: DrawerState,
    progressViewModel: UserProgressViewModel = viewModel(),
    onNavigate: (String) -> Unit,
    content: @Composable () -> Unit
) {
    val progress by progressViewModel.progress.collectAsState()
    val firestoreUsername by progressViewModel.username.collectAsState()
    val photoUrl by progressViewModel.photoUrl.collectAsState()
    val context = LocalContext.current

    // Observe real-time Firebase user — updates instantly on login/logout
    var firebaseUser by remember { mutableStateOf<FirebaseUser?>(FirebaseAuth.getInstance().currentUser) }
    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth -> firebaseUser = auth.currentUser }
        FirebaseAuth.getInstance().addAuthStateListener(listener)
        onDispose { FirebaseAuth.getInstance().removeAuthStateListener(listener) }
    }

    // Priority: Firestore username > Firebase displayName > email prefix > default
    val displayName = when {
        firestoreUsername.isNotBlank() -> firestoreUsername
        !firebaseUser?.displayName.isNullOrBlank() -> firebaseUser!!.displayName!!
        else -> firebaseUser?.email?.substringBefore("@")?.replaceFirstChar { it.uppercase() } ?: "Python Hero"
    }
    val displayEmail = firebaseUser?.email ?: "Not signed in"
    val avatarLetter = displayName.firstOrNull()?.uppercaseChar() ?: '?'

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = SurfaceDark,
                drawerShape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                modifier = Modifier.width(300.dp)
            ) {
                Column(modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState())) {

                    // ── Profile Header ──────────────────────────────────
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(listOf(ElectricViolet.copy(0.35f), SurfaceDark))
                            )
                            .padding(24.dp)
                    ) {
                        Column {
                            // Avatar circle with initial letter
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(Brush.radialGradient(listOf(VioletLight, ElectricViolet))),
                                contentAlignment = Alignment.Center
                            ) {
                                if (photoUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = photoUrl,
                                        contentDescription = "Profile photo",
                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                        contentScale = ContentScale.Crop
                                    )
                                } else if (firebaseUser != null) {
                                    Text(
                                        text = avatarLetter.toString(),
                                        fontSize = 30.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                } else {
                                    Text("🧑‍💻", fontSize = 36.sp)
                                }
                            }

                            Spacer(Modifier.height(12.dp))

                            // Real-time name + email
                            Text(displayName, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = TextPrimary)
                            Text(displayEmail, fontSize = 12.sp, color = TextMuted)

                            // Online indicator
                            if (firebaseUser != null) {
                                Spacer(Modifier.height(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF22C55E))
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text("Signed in", fontSize = 11.sp, color = Color(0xFF22C55E))
                                }
                            }

                            Spacer(Modifier.height(14.dp))

                            // Stats row
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                DrawerStat("⚡", "${progress.xp}", "XP")
                                DrawerStat("🔥", "${progress.streak}", "Streak")
                                DrawerStat("🏆", "Lv ${progress.level}", "Level")
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // XP Progress bar
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Level ${progress.level}", fontSize = 12.sp, color = TextMuted)
                            Text("${progress.xp} / ${progress.level * 100} XP", fontSize = 12.sp, color = XpGold)
                        }
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { progress.levelProgress },
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = XpGold, trackColor = SurfaceVariantDark
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    HorizontalDivider(color = SurfaceVariantDark)
                    Spacer(Modifier.height(8.dp))

                    // ── Main Nav Items ──────────────────────────────────
                    val navItems = listOf(
                        DrawerNavItem("home", Icons.Default.Home, "Home"),
                        DrawerNavItem("profile", Icons.Default.Person, "My Profile"),
                        DrawerNavItem("leaderboard", Icons.Default.Leaderboard, "Leaderboard"),
                        DrawerNavItem("search", Icons.Default.Search, "Search"),
                    )
                    navItems.forEach { item ->
                        DrawerNavRow(item = item, onClick = { onNavigate(item.route) })
                    }

                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider(color = SurfaceVariantDark)
                    Spacer(Modifier.height(8.dp))

                    DrawerNavRow(
                        DrawerNavItem("settings", Icons.Default.Settings, "Settings"),
                        onClick = { onNavigate("settings") }
                    )
                    DrawerNavRow(
                        DrawerNavItem("code", Icons.Default.Code, "Code Playground"),
                        onClick = { onNavigate("code") }
                    )
                    DrawerNavRow(
                        DrawerNavItem("rate", Icons.Default.Star, "Rate Us ⭐"),
                        onClick = {
                            runCatching {
                                context.startActivity(
                                    Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("market://details?id=${context.packageName}")
                                    )
                                )
                            }
                        }
                    )
                    DrawerNavRow(
                        DrawerNavItem("share", Icons.Default.Share, "Share App"),
                        onClick = {
                            context.startActivity(
                                Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "I’m learning to code with Python Hero!"
                                        )
                                    },
                                    "Share Python Hero"
                                )
                            )
                        }
                    )

                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider(color = SurfaceVariantDark)
                    Spacer(Modifier.height(8.dp))

                    // ── Sign Out Button ─────────────────────────────────
                    NavigationDrawerItem(
                        icon = {
                            Icon(
                                Icons.Default.Logout,
                                contentDescription = "Sign Out",
                                tint = Color(0xFFEF4444)
                            )
                        },
                        label = {
                            Text(
                                "Sign Out",
                                color = Color(0xFFEF4444),
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        selected = false,
                        onClick = { onNavigate("logout") },
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                        colors = NavigationDrawerItemDefaults.colors(
                            unselectedContainerColor = Color(0xFFEF4444).copy(alpha = 0.08f)
                        )
                    )

                    Spacer(Modifier.height(16.dp))

                    // ── PRO Banner ──────────────────────────────────────
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Brush.horizontalGradient(listOf(Color(0xFFEA580C), Color(0xFFDC2626))))
                                .padding(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("👑", fontSize = 24.sp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text("Go PRO!", fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 15.sp)
                                    Text("Unlock all courses", color = Color.White.copy(0.8f), fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))
                }
            }
        },
        content = content
    )
}

data class DrawerNavItem(val route: String, val icon: ImageVector, val label: String)

@Composable
fun DrawerNavRow(item: DrawerNavItem, onClick: () -> Unit) {
    NavigationDrawerItem(
        icon = { Icon(item.icon, contentDescription = null, tint = TextSecondary) },
        label = { Text(item.label, color = TextPrimary, fontWeight = FontWeight.SemiBold) },
        selected = false,
        onClick = onClick,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        colors = NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = Color.Transparent,
            selectedContainerColor = ElectricViolet.copy(0.15f)
        )
    )
}

@Composable
fun DrawerStat(emoji: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(emoji, fontSize = 14.sp)
        Text(value, fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 13.sp)
        Text(label, fontSize = 10.sp, color = TextMuted)
    }
}
