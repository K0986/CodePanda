package com.example.myapplication.data

import com.example.myapplication.model.*

data class CourseCategory(
    val title: String,
    val emoji: String,
    val courses: List<Course>
)

object AllCoursesData {

    // ── Python ────────────────────────────────────────────────────
    val python = Course(
        id = "python", title = "Python", description = "Master Python from scratch.",
        trending = true, progress = 0f, tag = "BEGINNER",
        gradientStart = 0xFF0D9488, gradientEnd = 0xFF0891B2,
        units = PythonCourseData.pythonCourse.units
    )
    val python3 = Course(
        id = "python3", title = "Python 3", description = "Python 3 in depth.",
        isNew = true, tag = "INTERMEDIATE",
        gradientStart = 0xFF0D9488, gradientEnd = 0xFF065F46,
        units = listOf(
            CourseUnit("p3u1", "🐍 Python 3 Basics", lessons = listOf(
                Lesson("p3l1", "What's New in Python 3", LessonType.CONTENT, 5, xpReward = 10,
                    content = listOf(
                        LessonContent.Text("Python 3 Improvements 🚀", isHeader = true),
                        LessonContent.Text("Python 3 introduced print() as a function, better Unicode support, and many improvements over Python 2."),
                        LessonContent.CodeSnippet("# Python 3 print is a function\nprint(\"Hello World\")  # ✅\n# print \"Hello World\"  # ❌ Python 2 only"),
                        LessonContent.Quiz("Which is valid Python 3?", listOf("print \"hello\"","print(\"hello\")","echo \"hello\"","System.out.println(\"hello\")"), 1, "Python 3 uses print() as a function!")
                    )
                ),
                Lesson("p3l2", "f-Strings & Formatting", LessonType.CONTENT, 6, xpReward = 10,
                    content = listOf(
                        LessonContent.Text("f-Strings — Modern Python Formatting ✨", isHeader = true),
                        LessonContent.CodeSnippet("name = \"Hero\"\nscore = 100\nprint(f\"Hello {name}, score: {score}\")\nprint(f\"Double: {score * 2}\")"),
                        LessonContent.Quiz("f-strings start with?", listOf("s\"\"", "f\"\"", "r\"\"", "b\"\""), 1, "f\"\" tells Python to format variables inside {}")
                    )
                )
            ))
        )
    )
    val pythonAdvanced = Course(
        id = "python_advanced", title = "Python Advanced", description = "OOP, decorators, generators.",
        isNew = false, trending = false, tag = "ADVANCED",
        gradientStart = 0xFF1D4ED8, gradientEnd = 0xFF7C3AED,
        units = listOf(
            CourseUnit("pau1", "⚡ Advanced Concepts", lessons = listOf(
                Lesson("pal1", "Object Oriented Python", LessonType.CONTENT, 10, xpReward = 20,
                    content = listOf(
                        LessonContent.Text("Classes & Objects 🏗️", isHeader = true),
                        LessonContent.Text("OOP lets you model real-world things as objects with properties (attributes) and behaviors (methods)."),
                        LessonContent.CodeSnippet("class Hero:\n    def __init__(self, name, xp):\n        self.name = name\n        self.xp = xp\n\n    def level_up(self):\n        print(f\"{self.name} leveled up! 🏆\")\n\nhero = Hero(\"Kundan\", 100)\nhero.level_up()"),
                        LessonContent.Quiz("What is 'self' in a class method?", listOf("A keyword like 'this'","Reference to the instance","A module","A function"), 1, "self refers to the current object instance!")
                    )
                ),
                Lesson("pal2", "Decorators", LessonType.CONTENT, 12, xpReward = 25,
                    content = listOf(
                        LessonContent.Text("Decorators — Functions that wrap Functions 🎁", isHeader = true),
                        LessonContent.CodeSnippet("def timer(func):\n    def wrapper():\n        print(\"Starting...\")\n        func()\n        print(\"Done!\")\n    return wrapper\n\n@timer\ndef greet():\n    print(\"Hello Hero!\")\n\ngreet()"),
                        LessonContent.Quiz("What does @decorator do?", listOf("Creates a class","Wraps a function","Deletes a function","Imports a module"), 1, "@decorator applies the decorator function automatically!")
                    )
                )
            ))
        )
    )
    val aiPython = Course(
        id = "ai_python", title = "AI with Python", description = "Build AI apps using Python.",
        isNew = true, tag = "AI",
        gradientStart = 0xFF7C3AED, gradientEnd = 0xFFEC4899,
        units = listOf(CourseUnit("aiu1","🤖 AI Fundamentals", lessons = listOf(
            Lesson("ail1","What is AI?", LessonType.CONTENT, 8, xpReward=15,
                content = listOf(
                    LessonContent.Text("Artificial Intelligence 101 🤖", isHeader=true),
                    LessonContent.Text("AI is the simulation of human intelligence in machines. Python is the #1 language for AI development!"),
                    LessonContent.CodeSnippet("# Simple AI prediction example\nimport random\n\ndef predict_weather():\n    return random.choice([\"☀️ Sunny\",\"🌧️ Rainy\",\"⛅ Cloudy\"])\n\nprint(predict_weather())"),
                    LessonContent.Quiz("Why is Python popular for AI?", listOf("It's the fastest language","Rich libraries like NumPy, TensorFlow","It was made for AI","It's the oldest language"), 1, "Python has NumPy, Pandas, TensorFlow, PyTorch and more!")
                )
            )
        )))
    )

    // ── Web ────────────────────────────────────────────────────────
    val html = Course(
        id = "html", title = "HTML & CSS", description = "Build beautiful websites from scratch.",
        progress = 0f, tag = "WEB",
        gradientStart = 0xFFEA580C, gradientEnd = 0xFFDC2626,
        units = listOf(CourseUnit("hu1","🌐 HTML Basics", lessons = listOf(
            Lesson("hl1","What is HTML?", LessonType.CONTENT, 5, xpReward=10,
                content = listOf(
                    LessonContent.Text("HTML — The Skeleton of the Web 🌐", isHeader=true),
                    LessonContent.Text("HTML (HyperText Markup Language) is the standard language for creating web pages."),
                    LessonContent.CodeSnippet("<!DOCTYPE html>\n<html>\n  <head>\n    <title>My Page</title>\n  </head>\n  <body>\n    <h1>Hello World! 🌍</h1>\n    <p>My first webpage.</p>\n  </body>\n</html>", language = "html"),
                    LessonContent.Quiz("What does HTML stand for?", listOf("Hyper Text Markup Language","High Tech Modern Language","Hyper Transfer Method Language","Home Tool Markup Language"), 0, "HTML = HyperText Markup Language!")
                )
            ),
            Lesson("hl2","HTML Tags & Elements", LessonType.CONTENT, 7, xpReward=10,
                content = listOf(
                    LessonContent.Text("HTML Tags 🏷️", isHeader=true),
                    LessonContent.Text("Tags are the building blocks of HTML. Most tags come in pairs: opening <tag> and closing </tag>."),
                    LessonContent.CodeSnippet("<h1>Big Heading</h1>\n<h2>Smaller Heading</h2>\n<p>A paragraph of text</p>\n<a href=\"https://example.com\">A Link</a>\n<img src=\"photo.jpg\" alt=\"Photo\">", language="html"),
                    LessonContent.Quiz("Which tag creates a link?", listOf("<link>","<a>","<href>","<url>"), 1, "<a href='...'> creates hyperlinks!")
                )
            )
        )))
    )
    val javascript = Course(
        id = "javascript", title = "JavaScript", description = "Make websites interactive and dynamic.",
        isNew = true, tag = "WEB",
        gradientStart = 0xFFF59E0B, gradientEnd = 0xFFEA580C,
        units = listOf(CourseUnit("jsu1","⚡ JS Fundamentals", lessons = listOf(
            Lesson("jsl1","Intro to JavaScript", LessonType.CONTENT, 6, xpReward=10,
                content = listOf(
                    LessonContent.Text("JavaScript — The Language of the Web ⚡", isHeader=true),
                    LessonContent.Text("JavaScript makes web pages interactive. It runs in every browser and is the world's most used language!"),
                    LessonContent.CodeSnippet("// Variables in JavaScript\nlet name = \"Python Hero\";\nconst score = 100;\n\n// Output\nconsole.log(`Hello, \${name}!`);\nconsole.log(`Your score: \${score}`);", language="javascript"),
                    LessonContent.Quiz("Which keyword declares a constant in JS?", listOf("var","let","const","def"), 2, "const declares a constant that cannot be reassigned!")
                )
            )
        )))
    )

    // ── Systems ────────────────────────────────────────────────────
    val cProg = Course(
        id = "c_programming", title = "C Programming", description = "Learn the language behind OS.",
        tag = "SYSTEMS", trending = true,
        gradientStart = 0xFF2563EB, gradientEnd = 0xFF1D4ED8,
        units = listOf(CourseUnit("cu1","⚙️ C Basics", lessons = listOf(
            Lesson("cl1","Hello World in C", LessonType.CONTENT, 6, xpReward=10,
                content = listOf(
                    LessonContent.Text("C Programming — The Foundation ⚙️", isHeader=true),
                    LessonContent.Text("C is one of the oldest and most powerful languages. Linux, Windows, and most operating systems are written in C!"),
                    LessonContent.CodeSnippet("#include <stdio.h>\n\nint main() {\n    printf(\"Hello, World!\\n\");\n    return 0;\n}", language="c"),
                    LessonContent.Quiz("What does printf() do in C?", listOf("Reads input","Prints output","Creates a function","Allocates memory"), 1, "printf() prints formatted text to the console!")
                )
            )
        )))
    )
    val cAdvanced = Course(
        id = "c_advanced", title = "C Advanced", description = "Pointers, memory, data structures.",
        tag = "SYSTEMS", trending = true,
        gradientStart = 0xFF1E40AF, gradientEnd = 0xFF1E3A5F,
        units = listOf(CourseUnit("cau1","🔬 Advanced C", lessons = listOf(
            Lesson("cal1","Pointers in C", LessonType.CONTENT, 10, xpReward=20,
                content = listOf(
                    LessonContent.Text("Pointers — The Power of C 🔬", isHeader=true),
                    LessonContent.Text("A pointer stores the memory address of another variable. This gives C direct memory control!"),
                    LessonContent.CodeSnippet("int x = 42;\nint *ptr = &x;  // ptr stores address of x\n\nprintf(\"%d\\n\", x);    // 42\nprintf(\"%d\\n\", *ptr); // 42 (dereference)\nprintf(\"%p\\n\", ptr);  // memory address", language="c"),
                    LessonContent.Quiz("What does * mean before a pointer variable?", listOf("Multiply","Declare pointer","Dereference — get the value","Nothing"), 2, "*ptr dereferences the pointer, getting the value at that memory address!")
                )
            )
        )))
    )
    val csharp = Course(
        id = "csharp", title = "C# (C Sharp)", description = "Build games with Unity and apps.",
        isNew = true, tag = "GAME",
        gradientStart = 0xFF7C3AED, gradientEnd = 0xFF4F46E5,
        units = listOf(CourseUnit("csu1","🎮 C# for Games", lessons = listOf(
            Lesson("csl1","Intro to C#", LessonType.CONTENT, 7, xpReward=10,
                content = listOf(
                    LessonContent.Text("C# — Power Behind Unity Games 🎮", isHeader=true),
                    LessonContent.Text("C# (C Sharp) is used for Unity game development, Windows apps, and enterprise software."),
                    LessonContent.CodeSnippet("using System;\n\nclass Hero {\n    static void Main() {\n        Console.WriteLine(\"Python Hero Game!\");\n        int score = 100;\n        Console.WriteLine($\"Score: {score}\");\n    }\n}", language="csharp"),
                    LessonContent.Quiz("Unity games are written in?", listOf("Java","Python","C#","JavaScript"), 2, "Unity uses C# as its primary scripting language!")
                )
            )
        )))
    )
    val java = Course(
        id = "java", title = "Java", description = "Object-oriented programming powerhouse.",
        trending = true, tag = "BACKEND",
        gradientStart = 0xFFB45309, gradientEnd = 0xFFEA580C,
        units = listOf(CourseUnit("jvu1","☕ Java Basics", lessons = listOf(
            Lesson("jvl1","Hello Java", LessonType.CONTENT, 6, xpReward=10,
                content = listOf(
                    LessonContent.Text("Java — Write Once, Run Anywhere ☕", isHeader=true),
                    LessonContent.Text("Java is used for Android apps, enterprise software, and backend web services. It runs on the JVM!"),
                    LessonContent.CodeSnippet("public class Main {\n    public static void main(String[] args) {\n        System.out.println(\"Hello, Hero!\");\n        int score = 100;\n        System.out.println(\"Score: \" + score);\n    }\n}", language="java"),
                    LessonContent.Quiz("Java apps run on?", listOf("JVM — Java Virtual Machine","Python Interpreter","Browser","Operating System directly"), 0, "JVM makes Java platform-independent — run on any OS!")
                )
            )
        )))
    )
    val ethicalHacking = Course(
        id = "ethical_hacking", title = "Ethical Hacking", description = "Learn cybersecurity & penetration testing.",
        trending = true, tag = "SECURITY",
        gradientStart = 0xFF065F46, gradientEnd = 0xFF14532D,
        units = listOf(CourseUnit("ehu1","🔐 Security Basics", lessons = listOf(
            Lesson("ehl1","What is Ethical Hacking?", LessonType.CONTENT, 7, xpReward=10,
                content = listOf(
                    LessonContent.Text("Ethical Hacking — Hacking for Good 🔐", isHeader=true),
                    LessonContent.Text("Ethical hackers (white hats) test systems for vulnerabilities with permission, to fix them before criminals exploit them."),
                    LessonContent.Text("Types of Hackers:\n• 🎩 White Hat — Ethical/Legal\n• 🖤 Black Hat — Criminal\n• 🩶 Grey Hat — In between"),
                    LessonContent.Quiz("Ethical hacking requires?", listOf("No permission","Written permission from owner","Only verbal permission","Nothing"), 1, "Always get written permission before penetration testing!")
                )
            )
        )))
    )

    // ── All categories ──────────────────────────────────────────────
    val categories = listOf(
        CourseCategory("MOST RECOMMENDED ✨", "✨", listOf(python, ethicalHacking, java, html)),
        CourseCategory("ALL ABOUT PYTHON 🐍", "🐍", listOf(python, python3, pythonAdvanced, aiPython)),
        CourseCategory("FOR ABSOLUTE BEGINNERS 👨‍💻", "👨‍💻", listOf(cProg, cAdvanced, javascript, html)),
        CourseCategory("GENERATIVE AI 🤖", "🤖", listOf(aiPython,
            Course("prompt_eng","Prompt Engineering","Master prompt writing for AI.",isNew=true,tag="AI",gradientStart=0xFFEC4899,gradientEnd=0xFFBE185D),
            Course("chatgpt","ChatGPT Mastery","Use ChatGPT like a pro.",isNew=true,tag="AI",gradientStart=0xFF7C3AED,gradientEnd=0xFFEC4899)
        )),
        CourseCategory("BUILD YOUR FIRST GAME 🎮", "🎮", listOf(csharp,
            Course("csharp_advanced","C# Advanced","Deep dive into C# and Unity.",isNew=true,tag="GAME",gradientStart=0xFF4F46E5,gradientEnd=0xFF2563EB),
            Course("unity","Game Dev with Unity","Build 2D & 3D games.",isNew=true,tag="GAME",gradientStart=0xFF1D4ED8,gradientEnd=0xFF4F46E5)
        )),
        CourseCategory("MUST-LEARN ESSENTIALS 📚", "📚", listOf(java, javascript,
            Course("kotlin","Kotlin","Modern Android development.",isNew=true,tag="MOBILE",gradientStart=0xFF7C3AED,gradientEnd=0xFF06B6D4),
            Course("php","PHP","Server-side web scripting.",isNew=true,tag="WEB",gradientStart=0xFF6B21A8,gradientEnd=0xFF4F46E5)
        ))
    )

    val allCourses = listOf(python, python3, pythonAdvanced, aiPython, html, javascript, cProg, cAdvanced, csharp, java, ethicalHacking)

    fun findCourseById(id: String): Course? = allCourses.find { it.id == id }
        ?: categories.flatMap { it.courses }.find { it.id == id }

    // Cheat sheet content per course
    fun getCheatSheet(courseId: String): List<Pair<String, String>> = when (courseId) {
        "python", "python3", "python_advanced" -> listOf(
            "Variables" to "x = 5\nname = 'Hero'\npi = 3.14",
            "Print" to "print('Hello')\nprint(f'Name: {name}')",
            "If/Else" to "if x > 0:\n    print('positive')\nelif x == 0:\n    print('zero')\nelse:\n    print('negative')",
            "For Loop" to "for i in range(5):\n    print(i)\n\nfor item in list:\n    print(item)",
            "While Loop" to "while x > 0:\n    x -= 1",
            "Functions" to "def greet(name):\n    return f'Hello {name}'\n\nresult = greet('Hero')",
            "Lists" to "nums = [1, 2, 3]\nnums.append(4)\nnums.remove(1)\nlen(nums)",
            "Dictionaries" to "data = {'name': 'Hero', 'xp': 100}\ndata['level'] = 2\nprint(data['name'])",
            "Classes" to "class Animal:\n    def __init__(self, name):\n        self.name = name\n    def speak(self):\n        return 'Sound!'",
            "List Comprehension" to "[x*2 for x in range(10)]\n[x for x in nums if x > 0]"
        )
        "html" -> listOf(
            "Document Structure" to "<!DOCTYPE html>\n<html>\n<head><title>Page</title></head>\n<body>Content</body>\n</html>",
            "Headings" to "<h1>Big</h1>\n<h2>Medium</h2>\n<h3>Small</h3>",
            "Text" to "<p>Paragraph</p>\n<strong>Bold</strong>\n<em>Italic</em>",
            "Links" to "<a href='url'>Click here</a>",
            "Images" to "<img src='file.jpg' alt='Description'>",
            "Lists" to "<ul><li>Item</li></ul>\n<ol><li>Item</li></ol>",
            "CSS Basics" to "color: red;\nfont-size: 16px;\nbackground: blue;\nmargin: 10px;"
        )
        "javascript" -> listOf(
            "Variables" to "let x = 5;\nconst name = 'Hero';\nvar old = true;",
            "Functions" to "function greet(name) {\n  return `Hello \${name}`;\n}\nconst arrow = (x) => x * 2;",
            "Arrays" to "const arr = [1,2,3];\narr.push(4);\narr.map(x => x*2);\narr.filter(x => x>1);",
            "Objects" to "const obj = {name:'Hero', xp:100};\nobj.level = 2;\nconsole.log(obj.name);",
            "DOM" to "document.getElementById('id');\ndocument.querySelector('.class');\nelement.innerHTML = 'text';"
        )
        else -> listOf(
            "Getting Started" to "# This course is coming soon!\n# Check back for more content.",
            "Practice" to "# The best way to learn is practice.\n# Try writing code every day!"
        )
    }

    fun getCompilerStarter(courseId: String): String = when (courseId) {
        "python", "python3" -> "# Python Playground 🐍\n# Write your code here and press RUN!\n\nname = input('Enter your name: ')\nprint(f'Hello, {name}! Welcome to Python! 🚀')\n\n# Try changing the code above!"
        "python_advanced" -> "# Advanced Python\nclass Hero:\n    def __init__(self, name):\n        self.name = name\n        self.xp = 0\n    \n    def earn_xp(self, amount):\n        self.xp += amount\n        print(f'{self.name} earned {amount} XP! Total: {self.xp}')\n\nhero = Hero('You')\nhero.earn_xp(10)"
        "html" -> "<!-- HTML Playground -->\n<!DOCTYPE html>\n<html>\n<head>\n  <title>My Page</title>\n  <style>\n    body { font-family: Arial; background: #1a1035; color: white; padding: 20px; }\n    h1 { color: #7c3aed; }\n  </style>\n</head>\n<body>\n  <h1>Hello World! 🌍</h1>\n  <p>Edit this and press RUN!</p>\n</body>\n</html>"
        "javascript" -> "// JavaScript Playground ⚡\nconst name = 'Python Hero';\nconst score = 100;\n\nconsole.log(`Hello, \${name}!`);\nconsole.log(`Score: \${score}`);\n\n// Simple function\nfunction addXP(current, amount) {\n  return current + amount;\n}\n\nconsole.log('New score:', addXP(score, 50));"
        "c_programming", "c_advanced" -> "#include <stdio.h>\n\nint main() {\n    // C Playground ⚙️\n    char name[] = \"Python Hero\";\n    int score = 100;\n    \n    printf(\"Hello, %s!\\n\", name);\n    printf(\"Score: %d\\n\", score);\n    \n    return 0;\n}"
        "java" -> "// Java Playground ☕\npublic class Main {\n    public static void main(String[] args) {\n        String name = \"Python Hero\";\n        int score = 100;\n        \n        System.out.println(\"Hello, \" + name + \"!\");\n        System.out.println(\"Score: \" + score);\n    }\n}"
        else -> "# Welcome to the Playground! 🎮\n# This course compiler is coming soon.\n# For now, try Python:\n\nprint('Hello, Python Hero!')\nprint('Keep learning! 🚀')"
    }
}
