package com.example.myapplication.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.ui.components.GlowButton
import com.example.myapplication.ui.theme.*
import com.example.myapplication.viewmodel.LessonViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompilerScreen(
    courseId: String,
    onBack: () -> Unit,
    lessonViewModel: LessonViewModel = viewModel()
) {
    var code by remember { mutableStateOf(AllCoursesData.getCompilerStarter(courseId)) }
    var output by remember { mutableStateOf("") }
    var isRunning by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf(0) } // 0=Code, 1=Output
    val aiResponse by lessonViewModel.aiResponse.collectAsState()
    val isLoading by lessonViewModel.isLoading.collectAsState()

    // When AI responds, show as output
    LaunchedEffect(aiResponse) {
        if (aiResponse != null && isRunning) {
            output = aiResponse ?: ""
            isRunning = false
            selectedTab = 1
        }
    }

    fun runCode() {
        isRunning = true
        val prompt = """
            You are a Python/code interpreter. The user wrote this code:
            
            ```
            $code
            ```
            
            Simulate running this code and show ONLY the output (what would be printed/returned).
            If there's an error, show the error message. Be brief — just the output, no explanation.
            For input() calls, use "Python Hero" as the default input.
        """.trimIndent()
        lessonViewModel.askAI("Code Execution", prompt)
    }

    Scaffold(
        containerColor = Color(0xFF0D1117),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("⚡", fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("Compiler", fontWeight = FontWeight.ExtraBold, color = TextPrimary)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = TextPrimary)
                    }
                },
                actions = {
                    TextButton(onClick = { code = AllCoursesData.getCompilerStarter(courseId) }) {
                        Text("Reset", color = TextSecondary, fontSize = 13.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF161B22))
            )
        },
        bottomBar = {
            Column {
                // Quick insert toolbar
                Surface(color = Color(0xFF161B22)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("TAB", "{", "}", "(", ")", ":", "=", "#", "\"", "'", "[", "]", "→").forEach { sym ->
                            Surface(
                                onClick = {
                                    val insert = if (sym == "TAB") "    " else sym
                                    code += insert
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFF21262D),
                                border = BorderStroke(1.dp, Color(0xFF30363D))
                            ) {
                                Text(
                                    sym,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = Color(0xFFD4D4D4)
                                )
                            }
                        }
                    }
                }

                // Run button
                Box(modifier = Modifier.background(Color(0xFF0D1117)).padding(12.dp)) {
                    GlowButton(
                        text = if (isRunning || isLoading) "⏳ RUNNING..." else "▶ RUN",
                        enabled = !isRunning && !isLoading,
                        onClick = { runCode() },
                        gradientColors = listOf(Color(0xFF22C55E), Color(0xFF16A34A)),
                        glowColor = Color(0xFF22C55E),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(Color(0xFF0D1117))
        ) {
            // Code / Output Tab
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161B22))
            ) {
                listOf("Code", "Output").forEachIndexed { idx, tab ->
                    val isSelected = selectedTab == idx
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedTab = idx }
                            .background(
                                if (isSelected) Brush.verticalGradient(listOf(ElectricViolet.copy(0.3f), Color.Transparent))
                                else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            tab,
                            color = if (isSelected) ElectricViolet else TextMuted,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0D1117))
            ) {
                if (selectedTab == 0) {
                    // Code editor with line numbers
                    Row(modifier = Modifier.fillMaxSize()) {
                        // Line numbers
                        val lines = code.lines()
                        Column(
                            modifier = Modifier
                                .background(Color(0xFF161B22))
                                .padding(horizontal = 12.dp, vertical = 16.dp)
                                .width(40.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            lines.forEachIndexed { i, _ ->
                                Text(
                                    "${i + 1}",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = Color(0xFF6E7681),
                                    lineHeight = 22.sp
                                )
                            }
                        }
                        // Editor
                        BasicTextField(
                            value = code,
                            onValueChange = { code = it },
                            textStyle = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 13.sp,
                                color = Color(0xFFD4D4D4),
                                lineHeight = 22.sp
                            ),
                            cursorBrush = SolidColor(ElectricViolet),
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState())
                        )
                    }
                } else {
                    // Output
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        if (isLoading || isRunning) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Spacer(Modifier.height(48.dp))
                                CircularProgressIndicator(color = Color(0xFF22C55E))
                                Spacer(Modifier.height(16.dp))
                                Text("Executing...", color = Color(0xFF22C55E), fontFamily = FontFamily.Monospace)
                            }
                        } else if (output.isEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(top = 48.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("▶", fontSize = 48.sp, color = Color(0xFF30363D))
                                Spacer(Modifier.height(16.dp))
                                Text("Press RUN to execute your code", color = Color(0xFF6E7681), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                            }
                        } else {
                            // Output header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                    .background(Color(0xFF161B22))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(modifier = Modifier.size(10.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFF22C55E)))
                                Spacer(Modifier.width(6.dp))
                                Text("Output", fontSize = 11.sp, color = Color(0xFF6E7681), fontFamily = FontFamily.Monospace)
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                                    .background(Color(0xFF161B22))
                                    .padding(16.dp)
                            ) {
                                Text(
                                    output,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp,
                                    color = Color(0xFFD4D4D4),
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
