package com.example.myapplication.data

import android.net.Uri
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageMetadata
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Single source of truth for all Firestore / Storage operations.
 *
 * Firestore schema  users/{uid}:
 * {
 *   username, email, photoUrl,
 *   xp, level, streak, heartsLeft, dailyXpEarned,
 *   totalLessonsCompleted, completedLessonIds: List<String>,
 *   coursesProgress: Map<courseId, Double 0-1>,
 *   lastActiveCourseId, lastActiveLessonId,
 *   createdAt
 * }
 */
object FirestoreRepository {
    private const val TAG = "FirestoreRepo"
    private const val USERS = "users"

    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private val uid get() = auth.currentUser?.uid

    // ─── Profile ──────────────────────────────────────────────────────────────

    suspend fun saveUserProfile(username: String, photoUrl: String? = null) {
        val id = uid ?: return
        val data = mutableMapOf<String, Any>(
            "username" to username,
            "email" to (auth.currentUser?.email ?: ""),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (photoUrl != null) data["photoUrl"] = photoUrl
        db.collection(USERS).document(id).set(data, SetOptions.merge()).await()
        Log.d(TAG, "Profile saved: $username")
    }

    /** Upload photo to Firebase Storage, return download URL */
    suspend fun uploadProfilePhoto(uri: Uri, contentType: String = "image/jpeg"): Result<String> {
        val id = uid ?: return Result.failure(
            IllegalStateException("You need to be signed in before uploading a photo.")
        )
        // Firebase Storage requires paid plan — use CloudinaryUploader instead.
        // This method is kept for compatibility but no longer does Storage operations.
        return Result.failure(Exception("Use CloudinaryUploader.uploadProfilePhoto() instead."))
    }

    /** Update a single field in the user's Firestore document. */
    suspend fun updateUserField(uid: String, field: String, value: Any) {
        try {
            db.collection(USERS).document(uid)
                .set(mapOf(field to value, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge())
                .await()
            Log.d(TAG, "Updated $field for $uid")
        } catch (e: Exception) {
            Log.e(TAG, "updateUserField($field) failed", e)
        }
    }

    // ─── Progress Sync ────────────────────────────────────────────────────────

    /** Read the current user snapshot. The view model merges it with local state. */
    suspend fun fetchAndMergeUserData(
        localXp: Int,
        localLevel: Int,
        localStreak: Int,
        localHearts: Int,
        localDailyXp: Int,
        localLessonsCompleted: Int,
        localCompletedIds: Set<String>,
        localCoursesProgress: Map<String, Float>
    ): Map<String, Any>? {
        val id = uid ?: return null
        return try {
            val snap = db.collection(USERS).document(id).get().await()
            snap.data
        } catch (e: Exception) {
            Log.e(TAG, "fetchAndMergeUserData failed", e)
            null
        }
    }

    suspend fun syncProgress(
        xp: Int, level: Int, streak: Int, heartsLeft: Int,
        dailyXpEarned: Int, totalLessonsCompleted: Int,
        completedLessonIds: Set<String>, coursesProgress: Map<String, Float>,
        lastActiveCourseId: String = "", lastActiveLessonId: String = ""
    ) {
        val id = uid ?: return
        try {
            val data = mutableMapOf<String, Any>(
                "xp" to xp, "level" to level, "streak" to streak,
                "heartsLeft" to heartsLeft, "dailyXpEarned" to dailyXpEarned,
                "totalLessonsCompleted" to totalLessonsCompleted,
                "completedLessonIds" to completedLessonIds.toList(),
                "coursesProgress" to coursesProgress.mapValues { it.value.coerceIn(0f, 1f).toDouble() },
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (lastActiveCourseId.isNotBlank()) data["lastActiveCourseId"] = lastActiveCourseId
            if (lastActiveLessonId.isNotBlank()) data["lastActiveLessonId"] = lastActiveLessonId
            db.collection(USERS).document(id).set(data, SetOptions.merge()).await()
        } catch (e: Exception) {
            Log.e(TAG, "syncProgress failed", e)
            throw e
        }
    }

    suspend fun updateCourseProgress(courseId: String, progress: Float,
                                     lastLessonId: String = "") {
        val id = uid ?: return
        val data = mutableMapOf<String, Any>(
            "coursesProgress.$courseId" to progress.coerceIn(0f, 1f).toDouble(),
            "lastActiveCourseId" to courseId,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (lastLessonId.isNotBlank()) data["lastActiveLessonId"] = lastLessonId
        try {
            db.collection(USERS).document(id).update(data).await()
        } catch (e: Exception) {
            // First time field doesn't exist → merge set without losing profile data.
            db.collection(USERS).document(id).set(
                mapOf(
                    "coursesProgress" to mapOf(courseId to progress.coerceIn(0f, 1f).toDouble()),
                    "lastActiveCourseId" to courseId,
                    "lastActiveLessonId" to lastLessonId,
                    "updatedAt" to FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).await()
        }
    }

    // ─── Real-time listener ───────────────────────────────────────────────────

    fun userDataFlow(): Flow<Map<String, Any>?> = callbackFlow {
        val id = uid ?: run { trySend(null); close(); return@callbackFlow }
        val listener = db.collection(USERS).document(id).addSnapshotListener { snap, err ->
            if (err != null) {
                Log.e(TAG, "Listener error", err)
                close(err)
                return@addSnapshotListener
            }
            trySend(snap?.data)
        }
        awaitClose { listener.remove() }
    }
}
