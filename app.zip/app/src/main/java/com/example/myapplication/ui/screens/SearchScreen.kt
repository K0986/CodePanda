package com.example.myapplication.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.model.Course
import com.example.myapplication.ui.components.CourseLogo
import com.example.myapplication.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(onCourseClick: (Course) -> Unit, onBack: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    val results = remember(query) {
        if (query.isBlank()) emptyList()
        else AllCoursesData.allCourses.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.description.contains(query, ignoreCase = true) ||
            it.tag.contains(query, ignoreCase = true)
        }
    }

    val suggestions = listOf("Python", "Web", "Game", "AI", "Security", "Java", "Beginner")

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            TopAppBar(
                title = {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("Search courses...", color = TextMuted) },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, null, tint = TextMuted) },
                        trailingIcon = {
                            if (query.isNotBlank()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Default.Close, null, tint = TextMuted)
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { keyboard?.hide() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricViolet,
                            unfocusedBorderColor = SurfaceVariantDark,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricViolet
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().focusRequester(focusRequester)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().background(DeepSpace),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (query.isBlank()) {
                item {
                    Text("POPULAR SEARCHES", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                    Spacer(Modifier.height(10.dp))
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(suggestions) { tag ->
                            Surface(
                                onClick = { query = tag },
                                shape = RoundedCornerShape(20.dp),
                                color = SurfaceDark,
                                border = BorderStroke(1.dp, SurfaceVariantDark)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("🔍", fontSize = 14.sp)
                                    Spacer(Modifier.width(6.dp))
                                    Text(tag, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("ALL COURSES", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
                }
                items(AllCoursesData.allCourses) { course ->
                    SearchResultRow(course, onCourseClick)
                }
            } else if (results.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(top = 60.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🔍", fontSize = 48.sp)
                        Spacer(Modifier.height(12.dp))
                        Text("No results for \"$query\"", color = TextSecondary, fontWeight = FontWeight.SemiBold)
                        Text("Try a different keyword", color = TextMuted, fontSize = 13.sp)
                    }
                }
            } else {
                item {
                    Text(
                        "${results.size} course${if (results.size != 1) "s" else ""} found",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondary
                    )
                }
                items(results) { course ->
                    SearchResultRow(course, onCourseClick)
                }
            }
        }
    }
}

@Composable
fun SearchResultRow(course: Course, onClick: (Course) -> Unit) {
    Card(
        onClick = { onClick(course) },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, SurfaceVariantDark)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                CourseLogo(courseId = course.id, size = 52.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(course.title, fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 15.sp)
                Text(course.description, color = TextMuted, fontSize = 12.sp, maxLines = 1)
                Spacer(Modifier.height(4.dp))
                if (course.tag.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ElectricViolet.copy(0.2f)
                    ) {
                        Text(
                            course.tag,
                            fontSize = 10.sp,
                            color = VioletLight,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
        }
    }
}
