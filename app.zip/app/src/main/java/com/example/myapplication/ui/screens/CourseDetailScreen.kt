package com.example.myapplication.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.model.Course
import com.example.myapplication.model.Lesson
import com.example.myapplication.model.CourseUnit
import com.example.myapplication.model.LessonType
import com.example.myapplication.ui.components.CourseLogo
import com.example.myapplication.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CourseDetailScreen(
    course: Course,
    completedLessonIds: Set<String> = emptySet(),
    onBack: () -> Unit,
    onLessonSelect: (Lesson) -> Unit
) {
    val gradStart = Color(course.gradientStart)
    val gradEnd = Color(course.gradientEnd)
    val tabs = listOf("Index", "Compiler", "Cheats", "About")
    val pagerState = rememberPagerState(pageCount = { tabs.size })
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(course.title, fontWeight = FontWeight.ExtraBold, color = TextPrimary)
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = TextPrimary)
                        }
                    },
                    actions = {
                        // Course progress circle
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(end = 12.dp)) {
                            CircularProgressIndicator(
                                progress = { course.progress },
                                modifier = Modifier.size(36.dp),
                                color = gradStart, trackColor = SurfaceVariantDark, strokeWidth = 3.dp
                            )
                            Text("${(course.progress*100).toInt()}%", fontSize = 9.sp, color = TextPrimary, fontWeight = FontWeight.Bold)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = gradStart)
                )

                // Tab bar
                PrimaryScrollableTabRow(
                    selectedTabIndex = pagerState.currentPage,
                    containerColor = gradEnd,
                    contentColor = Color.White,
                    edgePadding = 8.dp,
                    indicator = {
                        // Let the default Primary indicator handle it, or we can customize.
                        // Using a simple styled indicator for PrimaryScrollableTabRow
                    },
                    divider = {} // Remove default divider
                ) {
                    tabs.forEachIndexed { index, tab ->
                        val isSelected = pagerState.currentPage == index
                        Tab(
                            selected = isSelected,
                            onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp).clip(RoundedCornerShape(16.dp)),
                            selectedContentColor = Color.White,
                            unselectedContentColor = Color.White.copy(alpha = 0.6f),
                            text = {
                                Text(
                                    tab,
                                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                    fontSize = 14.sp
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.padding(padding).fillMaxSize(),
            key = { it } // stable keys prevent recomposition bugs
        ) { page ->
            when (page) {
                0 -> IndexTab(
                    course = course,
                    completedLessonIds = completedLessonIds,
                    gradStart = gradStart,
                    gradEnd = gradEnd,
                    onLessonSelect = onLessonSelect
                )
                1 -> EmbeddedCompilerTab(courseId = course.id)
                2 -> EmbeddedCheatSheetTab(courseId = course.id, courseTitle = course.title)
                3 -> AboutTab(course)
            }
        }
    }
}

@Composable
fun IndexTab(
    course: Course,
    completedLessonIds: Set<String>,
    gradStart: Color,
    gradEnd: Color,
    onLessonSelect: (Lesson) -> Unit
) {
    val allLessons = remember(course.id) { course.units.flatMap { it.lessons } }
    val unlockedLessonIds = remember(course.id, completedLessonIds) {
        allLessons.mapIndexedNotNull { index, lesson ->
            if (index == 0 || allLessons[index - 1].id in completedLessonIds) lesson.id else null
        }.toSet()
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(DeepSpace),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            // Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(Brush.horizontalGradient(listOf(gradStart, gradEnd)))
            ) {
                Box(modifier = Modifier.align(Alignment.CenterEnd).padding(end = 24.dp).size(100.dp)) {
                    CourseLogo(courseId = course.id, size = 100.dp)
                }
                Column(modifier = Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                    Text(course.description, color = Color.White.copy(0.85f), fontSize = 13.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LinearProgressIndicator(
                            progress = { course.progress },
                            modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                            color = Color.White, trackColor = Color.White.copy(0.3f)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("${(course.progress*100).toInt()}%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        item { StreakShieldBanner() }

        if (course.units.isEmpty()) {
            item { HangOnScreen() }
        } else {
            itemsIndexed(course.units) { unitIndex, unit ->
                Spacer(Modifier.height(12.dp))
                GameUnitSection(
                    unit = unit,
                    unitIndex = unitIndex,
                    gradientColor = gradStart,
                    unlockedLessonIds = unlockedLessonIds,
                    onLessonSelect = onLessonSelect
                )
            }
        }
    }
}

@Composable
fun HangOnScreen() {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        // Animated robot
        val pulseAnim by rememberInfiniteTransition(label = "robot").animateFloat(
            0.95f, 1.05f,
            infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "robotPulse"
        )
        Box(
            modifier = Modifier
                .size(120.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(ElectricViolet.copy(0.4f), Color.Transparent))),
            contentAlignment = Alignment.Center
        ) {
            Text("🤖", fontSize = 64.sp, modifier = Modifier.scale(pulseAnim))
        }
        Spacer(Modifier.height(20.dp))
        Text("Hang On!", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = TextPrimary)
        Spacer(Modifier.height(8.dp))
        Text(
            "We are working on building the best content for you. Check back soon! 🚀",
            color = TextSecondary, fontSize = 14.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        // Progress bar animation
        val progressAnim by rememberInfiniteTransition(label = "load").animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(3000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
            label = "loadBar"
        )
        LinearProgressIndicator(
            progress = { progressAnim },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = ElectricViolet, trackColor = SurfaceVariantDark
        )
        Spacer(Modifier.height(8.dp))
        Text("${(progressAnim * 100).toInt()}%", color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
fun EmbeddedCompilerTab(courseId: String) {
    val lessonViewModel: com.example.myapplication.viewmodel.LessonViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val language = when {
        courseId.contains("python") || courseId.contains("ai") -> "python"
        courseId.contains("java") && !courseId.contains("javascript") -> "java"
        courseId.contains("javascript") -> "javascript"
        courseId.contains("html") -> "html"
        courseId.contains("kotlin") -> "kotlin"
        courseId.contains("c_") || courseId.contains("csharp") -> "c"
        else -> "python"
    }
    var code by remember(courseId) { mutableStateOf(AllCoursesData.getCompilerStarter(courseId)) }
    var selectedTab by remember { mutableStateOf(0) }
    val codeOutput by lessonViewModel.codeOutput.collectAsState()
    val isRunning by lessonViewModel.isRunning.collectAsState()

    LaunchedEffect(codeOutput) {
        if (codeOutput != null) selectedTab = 1
    }

    fun runCode() {
        lessonViewModel.runCode(language, code)
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFF0D1117))) {
        // Code / Output toggle
        Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF161B22))) {
            listOf("Code", "Output").forEachIndexed { i, label ->
                Box(
                    modifier = Modifier.weight(1f).clickable { selectedTab = i }
                        .background(if (selectedTab == i) ElectricViolet.copy(0.2f) else Color.Transparent)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = if (selectedTab == i) ElectricViolet else TextMuted,
                        fontWeight = if (selectedTab == i) FontWeight.ExtraBold else FontWeight.Normal, fontSize = 14.sp)
                }
            }
        }

        // Quick-insert toolbar
        Row(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF161B22))
                .horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("TAB","(",")",":","=","{","}","[","]","#","\"").forEach { sym ->
                Surface(
                    onClick = { code += if (sym == "TAB") "    " else sym },
                    shape = RoundedCornerShape(6.dp), color = Color(0xFF21262D),
                    border = BorderStroke(1.dp, Color(0xFF30363D))
                ) {
                    Text(sym, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 12.sp, color = Color(0xFFD4D4D4))
                }
            }
        }

        // Content area
        Box(modifier = Modifier.weight(1f)) {
            if (selectedTab == 0) {
                // Code editor
                Row(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier.background(Color(0xFF161B22))
                            .padding(horizontal = 8.dp, vertical = 12.dp).width(36.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        code.lines().forEachIndexed { i, _ ->
                            Text("${i+1}", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                fontSize = 12.sp, color = Color(0xFF6E7681), lineHeight = 20.sp)
                        }
                    }
                    androidx.compose.foundation.text.BasicTextField(
                        value = code, onValueChange = { code = it },
                        textStyle = androidx.compose.ui.text.TextStyle(
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                            fontSize = 13.sp, color = Color(0xFFD4D4D4), lineHeight = 22.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(ElectricViolet),
                        modifier = Modifier.fillMaxSize().padding(12.dp).verticalScroll(rememberScrollState())
                    )
                }
            } else {
                // Output area
                Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
                    if (isRunning) {
                        Column(modifier = Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF22C55E))
                            Spacer(Modifier.height(12.dp))
                            Text("Running with Gemini AI...", color = Color(0xFF22C55E), fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                        }
                    } else if (codeOutput == null) {
                        Column(modifier = Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("▶", fontSize = 48.sp, color = Color(0xFF30363D))
                            Spacer(Modifier.height(12.dp))
                            Text("Press RUN to execute", color = Color(0xFF6E7681), fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 13.sp)
                        }
                    } else {
                        Box(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF161B22)).padding(16.dp)) {
                            Text(codeOutput ?: "", fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                fontSize = 13.sp, color = Color(0xFFD4D4D4), lineHeight = 20.sp)
                        }
                    }
                }
            }
        }

        // Run button
        Box(modifier = Modifier.background(Color(0xFF0D1117)).padding(12.dp)) {
            Surface(
                onClick = { runCode() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (isRunning) Color(0xFF1A4731) else Color(0xFF22C55E)
            ) {
                Text(
                    if (isRunning) "⏳  Running..." else "▶  RUN",
                    modifier = Modifier.padding(vertical = 14.dp).fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun EmbeddedCheatSheetTab(courseId: String, courseTitle: String) {
    val cheatItems = remember(courseId) { AllCoursesData.getCheatSheet(courseId) }
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    var copiedTopic by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(DeepSpace),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = ElectricViolet.copy(0.12f)),
                border = BorderStroke(1.dp, ElectricViolet.copy(0.3f))
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("📋", fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Text("$courseTitle — Quick Reference", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                }
            }
        }
        items(cheatItems, key = { it.first }) { cheat ->
            var expanded by remember { mutableStateOf(true) }
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, SurfaceVariantDark)
            ) {
                Column {
                    Row(modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cheat.first, fontWeight = FontWeight.Bold, color = NeonCyan, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = {
                            clipboard.setText(androidx.compose.ui.text.AnnotatedString(cheat.second))
                            copiedTopic = cheat.first
                        }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.ContentCopy, null, tint = if (copiedTopic == cheat.first) CorrectGreen else TextMuted, modifier = Modifier.size(16.dp))
                        }
                        Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, tint = TextMuted, modifier = Modifier.size(20.dp))
                    }
                    AnimatedVisibility(visible = expanded) {
                        Box(modifier = Modifier.fillMaxWidth().background(Color(0xFF0D1117)).padding(14.dp)) {
                            Text(cheat.second, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                fontSize = 12.sp, color = Color(0xFFD4D4D4), lineHeight = 20.sp)
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun AboutTab(course: Course) {
    val cheatItems = AllCoursesData.getCheatSheet(course.id)
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(DeepSpace).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        item {
            Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("About ${course.title}", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(course.description, color = TextSecondary, lineHeight = 22.sp)
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        InfoChip("📚", "${course.units.size} Units")
                        InfoChip("⚡", "Earn XP")
                        InfoChip("🏆", course.tag)
                    }
                }
            }
        }
        item {
            Text("WHAT YOU'LL LEARN", style = MaterialTheme.typography.labelLarge, color = TextSecondary)
        }
        items(cheatItems.take(5)) { item ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = BorderStroke(1.dp, SurfaceVariantDark)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("✅", fontSize = 16.sp)
                    Spacer(Modifier.width(12.dp))
                    Text(item.first, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun InfoChip(emoji: String, text: String) {
    Surface(shape = RoundedCornerShape(8.dp), color = SurfaceVariantDark) {
        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 13.sp)
            Spacer(Modifier.width(4.dp))
            Text(text, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun StreakShieldBanner() {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = StreakOrange.copy(0.12f)),
        border = BorderStroke(1.dp, StreakOrange.copy(0.3f))
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔥", fontSize = 24.sp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Streak Shield Active", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 14.sp)
                Text("Keep going to maintain your streak!", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun GameUnitSection(
    unit: CourseUnit,
    unitIndex: Int,
    gradientColor: Color,
    unlockedLessonIds: Set<String> = emptySet(),
    onLessonSelect: (Lesson) -> Unit
) {
    var expanded by remember { mutableStateOf(unitIndex == 0) }
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        Surface(
            onClick = { expanded = !expanded },
            shape = RoundedCornerShape(16.dp),
            color = SurfaceDark,
            border = BorderStroke(1.dp, gradientColor.copy(0.3f))
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(40.dp).clip(CircleShape).background(gradientColor.copy(0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("${unitIndex + 1}", fontWeight = FontWeight.ExtraBold, color = gradientColor, fontSize = 16.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(unit.title, fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 15.sp)
                    Text("${unit.lessons.size} lessons", color = TextMuted, fontSize = 12.sp)
                }
                Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, tint = TextMuted)
            }
        }
        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 4.dp)) {
                unit.lessons.forEachIndexed { lessonIndex, lesson ->
                    GameLessonItem(lesson = lesson, lessonIndex = lessonIndex, accentColor = gradientColor,
                        isUnlocked = lesson.id in unlockedLessonIds,
                        animDelay = lessonIndex * 60, onClick = { onLessonSelect(lesson) })
                }
            }
        }
    }
}

@Composable
fun GameLessonItem(
    lesson: Lesson,
    lessonIndex: Int,
    accentColor: Color,
    isUnlocked: Boolean = true,
    animDelay: Int = 0,
    onClick: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(animDelay.toLong()); visible = true }
    val locked = lesson.isLocked || !isUnlocked
    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(initialOffsetX = { it / 2 }, animationSpec = spring(Spring.DampingRatioMediumBouncy)) + fadeIn()
    ) {
        Surface(
            onClick = { if (!locked) onClick() },
            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
            shape = RoundedCornerShape(14.dp),
            color = SurfaceDark,
            border = BorderStroke(1.dp, SurfaceVariantDark)
        ) {
            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                val statusEmoji = when {
                    locked -> "🔒"
                    lesson.type == LessonType.QUIZ -> "❓"
                    lesson.type == LessonType.CODE -> "💻"
                    else -> "📖"
                }
                val statusBg = if (locked) Color(0xFF374151) else accentColor.copy(0.15f)
                Box(
                    modifier = Modifier.size(36.dp).clip(CircleShape).background(statusBg),
                    contentAlignment = Alignment.Center
                ) { Text(statusEmoji, fontSize = 16.sp) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(lesson.title, fontWeight = FontWeight.SemiBold,
                        color = if (locked) TextMuted else TextPrimary, fontSize = 14.sp)
                    Text(
                        if (locked) "Complete the previous lesson to unlock" else "${lesson.durationMinutes} min",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
                if (!locked) {
                    Surface(shape = RoundedCornerShape(8.dp), color = XpGold.copy(0.15f)) {
                        Text("+${lesson.xpReward} XP", fontSize = 11.sp, color = XpGold,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }
            }
        }
    }
}
