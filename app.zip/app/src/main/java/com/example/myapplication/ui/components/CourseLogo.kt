package com.example.myapplication.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CourseLogo(
    courseId: String,
    size: Dp = 56.dp,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "logo_$courseId")

    val anim1 by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing)),
        label = "rot"
    )
    val anim2 by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val anim3 by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 6.28f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing)),
        label = "wave"
    )

    Canvas(modifier = modifier.size(size)) {
        when (courseId) {
            "python", "python3" -> drawPythonLogo(anim1, anim2, anim3)
            "html" -> drawHtmlLogo(anim1, anim2)
            "javascript" -> drawJsLogo(anim2)
            "java" -> drawJavaLogo(anim2, anim3)
            "c_programming", "c_advanced" -> drawCLogo(anim1, anim2)
            "csharp", "csharp_advanced" -> drawCSharpLogo(anim1, anim2)
            "ethical_hacking" -> drawSecurityLogo(anim2)
            "ai_python", "prompt_eng", "chatgpt" -> drawAiLogo(anim1, anim2)
            "unity", "game_dev" -> drawGameLogo(anim2)
            "kotlin" -> drawKotlinLogo(anim1, anim2)
            else -> drawDefaultLogo(anim2)
        }
    }
}

private fun DrawScope.drawPythonLogo(rot: Float, pulse: Float, wave: Float) {
    val cx = size.width / 2
    val cy = size.height / 2
    val r = size.width * 0.35f
    val scale = 0.9f + pulse * 0.1f

    // Snake body — sinusoidal path
    val path = Path()
    val segments = 20
    path.moveTo(cx - r * scale, cy)
    for (i in 0..segments) {
        val t = i.toFloat() / segments
        val x = cx - r * scale + t * r * 2 * scale
        val y = cy + sin(wave + t * 4 * Math.PI.toFloat()) * r * 0.3f * scale
        path.lineTo(x, y)
    }
    drawPath(path, color = Color(0xFF10B981), style = Stroke(width = size.width * 0.1f, cap = StrokeCap.Round, join = StrokeJoin.Round))

    // Snake head
    val headX = cx + r * scale + sin(wave) * r * 0.3f * scale
    val headY = cy + sin(wave + segments.toFloat() * 0.2f) * r * 0.3f * scale
    drawCircle(color = Color(0xFF34D399), radius = size.width * 0.1f, center = Offset(headX, headY))

    // Eyes
    drawCircle(color = Color.White, radius = size.width * 0.03f, center = Offset(headX + size.width * 0.03f, headY - size.width * 0.02f))
}

private fun DrawScope.drawHtmlLogo(rot: Float, pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f
    // < brackets
    val r = size.width * 0.35f * scale
    rotate(rot * 0.1f, Offset(cx, cy)) {
        // <
        drawLine(Color(0xFFEA580C), Offset(cx - r * 0.6f, cy - r * 0.5f), Offset(cx - r, cy), strokeWidth = size.width * 0.08f, cap = StrokeCap.Round)
        drawLine(Color(0xFFEA580C), Offset(cx - r, cy), Offset(cx - r * 0.6f, cy + r * 0.5f), strokeWidth = size.width * 0.08f, cap = StrokeCap.Round)
        // >
        drawLine(Color(0xFFDC2626), Offset(cx + r * 0.6f, cy - r * 0.5f), Offset(cx + r, cy), strokeWidth = size.width * 0.08f, cap = StrokeCap.Round)
        drawLine(Color(0xFFDC2626), Offset(cx + r, cy), Offset(cx + r * 0.6f, cy + r * 0.5f), strokeWidth = size.width * 0.08f, cap = StrokeCap.Round)
        // /
        drawLine(Color(0xFFF97316), Offset(cx + r * 0.2f, cy - r * 0.4f), Offset(cx - r * 0.2f, cy + r * 0.4f), strokeWidth = size.width * 0.08f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawJsLogo(pulse: Float) {
    val scale = 0.9f + pulse * 0.1f
    val r = size.width * 0.4f * scale
    val cx = size.width / 2; val cy = size.height / 2
    // JS rounded rect background
    drawRoundRect(
        brush = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFEA580C))),
        topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r * 0.2f)
    )
    // J stroke
    drawLine(Color.White, Offset(cx + r * 0.25f, cy - r * 0.4f), Offset(cx + r * 0.25f, cy + r * 0.2f), strokeWidth = size.width * 0.09f, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(cx + r * 0.25f, cy + r * 0.2f), Offset(cx - r * 0.1f, cy + r * 0.5f), strokeWidth = size.width * 0.09f, cap = StrokeCap.Round)
    // S stroke
    drawArc(Color.White, startAngle = 0f, sweepAngle = -180f, useCenter = false,
        topLeft = Offset(cx - r * 0.55f, cy - r * 0.4f), size = Size(r * 0.55f, r * 0.4f),
        style = Stroke(width = size.width * 0.09f, cap = StrokeCap.Round))
    drawArc(Color.White, startAngle = 180f, sweepAngle = -180f, useCenter = false,
        topLeft = Offset(cx - r * 0.55f, cy, ), size = Size(r * 0.55f, r * 0.4f),
        style = Stroke(width = size.width * 0.09f, cap = StrokeCap.Round))
}

private fun DrawScope.drawJavaLogo(pulse: Float, wave: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f
    // Coffee cup
    val cupW = size.width * 0.45f * scale; val cupH = size.height * 0.4f * scale
    drawRoundRect(Color(0xFFB45309), topLeft = Offset(cx - cupW / 2, cy - cupH * 0.3f),
        size = Size(cupW, cupH), cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f))
    // Steam
    for (i in 0..2) {
        val sx = cx - cupW * 0.2f + i * cupW * 0.2f
        val sy = cy - cupH * 0.3f - size.height * 0.1f
        val offset = sin(wave + i * 1f) * size.width * 0.05f
        drawLine(Color(0xFFEA580C).copy(alpha = 0.7f),
            Offset(sx + offset, sy), Offset(sx - offset, sy - size.height * 0.15f),
            strokeWidth = size.width * 0.05f, cap = StrokeCap.Round)
    }
    // Handle
    drawArc(Color(0xFFEA580C), 0f, 180f, false,
        topLeft = Offset(cx + cupW * 0.35f, cy), size = Size(cupW * 0.3f, cupH * 0.5f),
        style = Stroke(size.width * 0.07f, cap = StrokeCap.Round))
}

private fun DrawScope.drawCLogo(rot: Float, pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f
    val r = size.width * 0.38f * scale
    // Rotating gear-like C
    rotate(rot * 0.05f, Offset(cx, cy)) {
        drawArc(Brush.sweepGradient(listOf(Color(0xFF2563EB), Color(0xFF06B6D4))),
            startAngle = 40f, sweepAngle = 280f, useCenter = false,
            topLeft = Offset(cx - r, cy - r), size = Size(r * 2, r * 2),
            style = Stroke(size.width * 0.12f, cap = StrokeCap.Round))
    }
    // Center dot
    drawCircle(Color(0xFF06B6D4).copy(alpha = 0.5f + pulse * 0.3f), size.width * 0.08f, Offset(cx, cy))
}

private fun DrawScope.drawCSharpLogo(rot: Float, pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f
    val r = size.width * 0.35f * scale
    // C arc
    drawArc(Color(0xFF7C3AED), 40f, 280f, false,
        topLeft = Offset(cx - r * 0.8f, cy - r), size = Size(r * 1.6f, r * 2),
        style = Stroke(size.width * 0.1f, cap = StrokeCap.Round))
    // # lines
    val offset = r * 0.55f
    rotate(rot * 0.03f, Offset(cx + r * 0.3f, cy)) {
        drawLine(Color(0xFF9F67F0), Offset(cx + offset - r*0.15f, cy - r*0.4f), Offset(cx + offset - r*0.15f, cy + r*0.4f), size.width*0.07f, cap = StrokeCap.Round)
        drawLine(Color(0xFF9F67F0), Offset(cx + offset + r*0.15f, cy - r*0.4f), Offset(cx + offset + r*0.15f, cy + r*0.4f), size.width*0.07f, cap = StrokeCap.Round)
        drawLine(Color(0xFFBFA3F5), Offset(cx + offset - r*0.25f, cy - r*0.15f), Offset(cx + offset + r*0.25f, cy - r*0.15f), size.width*0.07f, cap = StrokeCap.Round)
        drawLine(Color(0xFFBFA3F5), Offset(cx + offset - r*0.25f, cy + r*0.15f), Offset(cx + offset + r*0.25f, cy + r*0.15f), size.width*0.07f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.drawSecurityLogo(pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f
    val r = size.width * 0.38f * scale
    // Shield shape
    val path = Path().apply {
        moveTo(cx, cy - r)
        lineTo(cx + r, cy - r * 0.5f)
        lineTo(cx + r, cy + r * 0.3f)
        lineTo(cx, cy + r)
        lineTo(cx - r, cy + r * 0.3f)
        lineTo(cx - r, cy - r * 0.5f)
        close()
    }
    drawPath(path, Brush.verticalGradient(listOf(Color(0xFF065F46), Color(0xFF10B981))))
    drawPath(path, Color(0xFF34D399), style = Stroke(size.width * 0.06f))
    // Lock body
    drawCircle(Color.White.copy(0.9f), r * 0.2f, Offset(cx, cy - r * 0.05f))
    drawRoundRect(Color.White.copy(0.9f), topLeft = Offset(cx - r * 0.2f, cy + r * 0.05f),
        size = Size(r * 0.4f, r * 0.35f), cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f))
}

private fun DrawScope.drawAiLogo(rot: Float, pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val r = size.width * 0.35f
    // Neural net nodes
    val nodes = listOf(
        Offset(cx, cy - r * 0.9f),
        Offset(cx - r * 0.8f, cy),
        Offset(cx + r * 0.8f, cy),
        Offset(cx, cy + r * 0.9f),
        Offset(cx, cy)
    )
    // Connections
    for (i in 0 until nodes.size - 1) {
        drawLine(Color(0xFF7C3AED).copy(alpha = 0.4f + pulse * 0.4f),
            nodes[i], nodes[4], strokeWidth = size.width * 0.04f)
    }
    // Nodes
    nodes.forEachIndexed { i, node ->
        val nodeScale = if (i == 4) 1.2f + pulse * 0.2f else 0.8f + pulse * 0.1f
        drawCircle(
            Brush.radialGradient(listOf(Color(0xFF9F67F0), Color(0xFF7C3AED)), center = node, radius = r * 0.2f * nodeScale),
            radius = r * 0.15f * nodeScale, center = node
        )
    }
}

private fun DrawScope.drawGameLogo(pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.85f + pulse * 0.15f
    val r = size.width * 0.38f * scale
    // Controller body
    drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFF4F46E5), Color(0xFF7C3AED))),
        topLeft = Offset(cx - r, cy - r * 0.6f), size = Size(r * 2, r * 1.2f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r * 0.5f))
    // Buttons
    drawCircle(Color(0xFFEF4444), r * 0.15f, Offset(cx + r * 0.55f, cy - r * 0.1f))
    drawCircle(Color(0xFF22C55E), r * 0.15f, Offset(cx + r * 0.35f, cy + r * 0.2f))
    // D-pad
    drawLine(Color.White, Offset(cx - r * 0.5f, cy - r * 0.3f), Offset(cx - r * 0.5f, cy + r * 0.3f), size.width * 0.1f, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(cx - r * 0.8f, cy), Offset(cx - r * 0.2f, cy), size.width * 0.1f, cap = StrokeCap.Round)
}

private fun DrawScope.drawKotlinLogo(rot: Float, pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val scale = 0.9f + pulse * 0.1f; val r = size.width * 0.4f * scale
    rotate(rot * 0.03f, Offset(cx, cy)) {
        val path = Path().apply {
            moveTo(cx - r, cy - r); lineTo(cx + r, cy - r)
            lineTo(cx, cy); lineTo(cx + r, cy + r)
            lineTo(cx - r, cy + r); close()
        }
        drawPath(path, Brush.linearGradient(listOf(Color(0xFF7C3AED), Color(0xFF06B6D4), Color(0xFF10B981)),
            start = Offset(cx - r, cy - r), end = Offset(cx + r, cy + r)))
    }
}

private fun DrawScope.drawDefaultLogo(pulse: Float) {
    val cx = size.width / 2; val cy = size.height / 2
    val r = size.width * 0.35f * (0.9f + pulse * 0.1f)
    drawCircle(Brush.radialGradient(listOf(Color(0xFF7C3AED), Color(0xFF4F46E5))), r, Offset(cx, cy))
    drawLine(Color.White, Offset(cx - r * 0.5f, cy), Offset(cx + r * 0.5f, cy), size.width * 0.1f, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(cx, cy - r * 0.5f), Offset(cx, cy + r * 0.5f), size.width * 0.1f, cap = StrokeCap.Round)
}
