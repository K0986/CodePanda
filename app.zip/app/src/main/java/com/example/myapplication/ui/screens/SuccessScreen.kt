package com.example.myapplication.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.components.GlowButton
import com.example.myapplication.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class ConfettiPiece(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val rotation: Float,
    val rotationSpeed: Float,
    val color: Color,
    val size: Float,
    val shape: Int // 0=circle, 1=rect
)

@Composable
fun SuccessScreen(onContinue: () -> Unit) {
    // Entry animations
    var contentVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(200)
        contentVisible = true
    }

    val trophyScale by animateFloatAsState(
        targetValue = if (contentVisible) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "trophy"
    )

    // XP counter animation
    var xpDisplay by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        delay(600)
        repeat(30) {
            xpDisplay = (it + 1)
            delay(30)
        }
    }

    // Confetti
    val confettiPieces = remember {
        List(60) {
            ConfettiPiece(
                x = Random.nextFloat(),
                y = Random.nextFloat() * -0.3f - 0.1f,
                vx = (Random.nextFloat() - 0.5f) * 0.003f,
                vy = Random.nextFloat() * 0.003f + 0.002f,
                rotation = Random.nextFloat() * 360f,
                rotationSpeed = (Random.nextFloat() - 0.5f) * 5f,
                color = listOf(
                    ElectricViolet, NeonCyan, XpGold, CorrectGreen,
                    Color(0xFFFF6B35), Color(0xFFEC4899), Color(0xFF06B6D4)
                ).random(),
                size = Random.nextFloat() * 10f + 6f,
                shape = Random.nextInt(2)
            )
        }
    }

    val confettiTime by rememberInfiniteTransition(label = "confetti").animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "confettiTime"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1A0A30), DeepSpace, Color(0xFF0A1A2A))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Confetti Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            confettiPieces.forEach { piece ->
                val t = confettiTime
                val cx = (piece.x + piece.vx * t * 1000 + sin(t * 6.28f + piece.x * 10) * 0.02f) * size.width
                val cy = ((piece.y + piece.vy * t * 1000) % 1.2f) * size.height
                val alpha = if (cy / size.height > 0.9f) (1f - (cy / size.height - 0.9f) / 0.1f) else 1f

                if (alpha > 0f && cy > 0f) {
                    if (piece.shape == 0) {
                        drawCircle(
                            color = piece.color.copy(alpha = alpha * 0.9f),
                            radius = piece.size / 2,
                            center = Offset(cx, cy)
                        )
                    } else {
                        drawRect(
                            color = piece.color.copy(alpha = alpha * 0.9f),
                            topLeft = Offset(cx - piece.size / 2, cy - piece.size / 4),
                            size = androidx.compose.ui.geometry.Size(piece.size, piece.size / 2)
                        )
                    }
                }
            }
        }

        // Glow blob
        Box(
            modifier = Modifier
                .size(300.dp)
                .graphicsLayer { alpha = 0.3f }
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(ElectricViolet, Color.Transparent)))
        )

        // Main content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Trophy
            Box(
                modifier = Modifier
                    .scale(trophyScale)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0xFFF59E0B).copy(alpha = 0.3f), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("🏆", fontSize = 72.sp)
            }

            Spacer(Modifier.height(20.dp))

            Text(
                "LESSON COMPLETE!",
                fontSize = 12.sp,
                fontWeight = FontWeight.ExtraBold,
                color = XpGold,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(8.dp))

            Text(
                "You did it! 🎉",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )

            Text(
                "That brain is absolutely on fire! 🔥",
                style = MaterialTheme.typography.bodyLarge,
                color = TextSecondary,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(Modifier.height(32.dp))

            // XP earned card
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = ElectricViolet.copy(alpha = 0.15f)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    ElectricViolet.copy(alpha = 0.4f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("⚡ XP Earned", color = TextSecondary, fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "+$xpDisplay",
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = XpGold
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    label = "Accuracy",
                    value = "100%",
                    emoji = "🎯",
                    color = CorrectGreen,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "Streak",
                    value = "🔥 Active",
                    emoji = "🔥",
                    color = StreakOrange,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    label = "Speed",
                    value = "Fast!",
                    emoji = "⚡",
                    color = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(32.dp))

            GlowButton(
                text = "NEXT LESSON →",
                onClick = onContinue,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    emoji: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.12f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            color.copy(alpha = 0.3f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                value,
                color = color,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(label, color = TextMuted, fontSize = 11.sp)
        }
    }
}
