package com.example.myapplication.ui.screens

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

// ── VS Code Dark+ Theme Colors ────────────────────────────────────────────────
private val SH_DEFAULT    = Color(0xFFD4D4D4)
private val SH_COMMENT    = Color(0xFF6A9955)  // green
private val SH_STRING     = Color(0xFFCE9178)  // orange
private val SH_KEYWORD    = Color(0xFF569CD6)  // blue
private val SH_CONTROL    = Color(0xFFC586C0)  // pink/purple (if, for, while, return)
private val SH_BUILTIN    = Color(0xFFDCDCAA)  // yellow (print, len, etc.)
private val SH_FUNC_DEF   = Color(0xFFDCDCAA)  // yellow (function name after def)
private val SH_CLASS_NAME = Color(0xFF4EC9B0)  // teal (class names)
private val SH_NUMBER     = Color(0xFFB5CEA8)  // light green
private val SH_DECORATOR  = Color(0xFFC586C0)  // purple
private val SH_SELF       = Color(0xFF9CDCFE)  // light blue
private val SH_OPERATOR   = Color(0xFFD4D4D4)
private val SH_TYPE       = Color(0xFF4EC9B0)  // teal (type names)
private val SH_BOOL_NONE  = Color(0xFF569CD6)  // blue (True, False, None)

// ── Tokenizer entry ───────────────────────────────────────────────────────────
data class SyntaxToken(val start: Int, val end: Int, val color: Color, val bold: Boolean = false)

fun highlightCode(code: String, language: String): AnnotatedString {
    if (code.isBlank()) return AnnotatedString(code)
    val tokens = when (language.lowercase().trim()) {
        "python", "py"                         -> tokenizePython(code)
        "javascript", "js"                     -> tokenizeJS(code)
        "typescript", "ts"                     -> tokenizeJS(code) // same as JS mostly
        "kotlin", "kt"                         -> tokenizeKotlin(code)
        "java"                                 -> tokenizeJava(code)
        "html"                                 -> tokenizeHTML(code)
        "css"                                  -> tokenizeCSS(code)
        "json"                                 -> tokenizeJSON(code)
        "bash", "sh", "shell", "powershell"    -> tokenizeBash(code)
        else                                   -> tokenizeGeneric(code)
    }
    return buildAnnotatedFromTokens(code, tokens)
}

// ── Shared tokenizer engine ───────────────────────────────────────────────────
private fun tokenize(code: String, patterns: List<Pair<Regex, Color>>): List<SyntaxToken> {
    val tokens = mutableListOf<SyntaxToken>()
    val marked = BooleanArray(code.length) { false }

    for ((regex, color) in patterns) {
        regex.findAll(code).forEach { match ->
            val r = match.range
            if (r.first >= code.length || r.last >= code.length) return@forEach
            if (r.any { marked[it] }) return@forEach   // already claimed
            r.forEach { marked[it] = true }
            tokens.add(SyntaxToken(r.first, r.last, color))
        }
    }
    return tokens.sortedBy { it.start }
}

private fun buildAnnotatedFromTokens(code: String, tokens: List<SyntaxToken>): AnnotatedString {
    return buildAnnotatedString {
        var pos = 0
        for (tok in tokens) {
            if (tok.start > pos) {
                withStyle(SpanStyle(color = SH_DEFAULT)) {
                    append(code.substring(pos, tok.start))
                }
            }
            val end = minOf(tok.end + 1, code.length)
            if (tok.start < end) {
                withStyle(SpanStyle(
                    color = tok.color,
                    fontWeight = if (tok.bold) FontWeight.Bold else null
                )) {
                    append(code.substring(tok.start, end))
                }
            }
            pos = tok.end + 1
        }
        if (pos < code.length) {
            withStyle(SpanStyle(color = SH_DEFAULT)) {
                append(code.substring(pos))
            }
        }
    }
}

// ── Python ────────────────────────────────────────────────────────────────────
private fun tokenizePython(code: String) = tokenize(code, listOf(
    // Comments
    Regex("""#[^\n]*""")                                                to SH_COMMENT,
    // Triple-quoted strings (must come before single)
    Regex("""\"\"\"[\s\S]*?\"\"\"""")                                   to SH_STRING,
    Regex("""\'\'\'[\s\S]*?\'\'\'""")                                   to SH_STRING,
    // Single-line strings
    Regex(""""[^"\n]*"""")                                              to SH_STRING,
    Regex("""'[^'\n]*'""")                                              to SH_STRING,
    // Decorators
    Regex("""@\w+""")                                                   to SH_DECORATOR,
    // Control keywords (pink)
    Regex("""\b(if|elif|else|for|while|return|break|continue|pass|yield|try|except|finally|raise|with|as|lambda|assert|del)\b""")
                                                                        to SH_CONTROL,
    // Definition keywords (blue)
    Regex("""\b(def|class|import|from|in|not|and|or|is|global|nonlocal|async|await)\b""")
                                                                        to SH_KEYWORD,
    // Booleans / None (blue)
    Regex("""\b(True|False|None)\b""")                                  to SH_BOOL_NONE,
    // self / cls (light blue)
    Regex("""\b(self|cls)\b""")                                         to SH_SELF,
    // Built-in functions (yellow)
    Regex("""\b(print|range|len|type|int|str|float|list|dict|set|tuple|bool|input|open|enumerate|zip|map|filter|sorted|reversed|sum|min|max|abs|round|repr|isinstance|issubclass|hasattr|getattr|setattr|delattr|super|property|staticmethod|classmethod|vars|dir|id|hash|iter|next|any|all|format|bin|hex|oct|pow|divmod|callable|complex|frozenset|bytes|bytearray|memoryview|object|Exception|ValueError|TypeError|KeyError|IndexError|AttributeError|StopIteration|RuntimeError|NotImplementedError)\b""")
                                                                        to SH_BUILTIN,
    // Function name after `def`
    Regex("""(?<=def )\w+""")                                           to SH_FUNC_DEF,
    // Class name after `class`
    Regex("""(?<=class )\w+""")                                         to SH_CLASS_NAME,
    // Numbers (int, float, hex, binary)
    Regex("""\b(0x[\da-fA-F]+|0b[01]+|\d+\.\d*|\.\d+|\d+)\b""")       to SH_NUMBER,
))

// ── JavaScript / TypeScript ───────────────────────────────────────────────────
private fun tokenizeJS(code: String) = tokenize(code, listOf(
    Regex("""//[^\n]*""")                                               to SH_COMMENT,
    Regex("""/\*[\s\S]*?\*/""")                                         to SH_COMMENT,
    Regex("""`[^`]*`""")                                                to SH_STRING,  // template literals
    Regex(""""[^"\n]*"""")                                              to SH_STRING,
    Regex("""'[^'\n]*'""")                                              to SH_STRING,
    Regex("""\b(if|else|for|while|do|switch|case|default|return|break|continue|throw|try|catch|finally|in|of|instanceof|typeof|void|delete|new|this|super|class|extends|import|export|from|as|async|await|yield)\b""")
                                                                        to SH_CONTROL,
    Regex("""\b(const|let|var|function|static|get|set)\b""")           to SH_KEYWORD,
    Regex("""\b(true|false|null|undefined|NaN|Infinity)\b""")          to SH_BOOL_NONE,
    Regex("""\b(console|Math|Array|Object|String|Number|Boolean|Promise|fetch|JSON|document|window|Symbol|Map|Set|WeakMap|WeakSet|Date|Error|RegExp|Proxy|Reflect|globalThis|process|require|module|exports)\b""")
                                                                        to SH_BUILTIN,
    Regex("""=>""")                                                     to SH_KEYWORD,
    Regex("""(?<=function )\w+""")                                      to SH_FUNC_DEF,
    Regex("""(?<=class )\w+""")                                         to SH_CLASS_NAME,
    Regex("""\b\d+\.?\d*\b""")                                         to SH_NUMBER,
))

// ── Kotlin ────────────────────────────────────────────────────────────────────
private fun tokenizeKotlin(code: String) = tokenize(code, listOf(
    Regex("""//[^\n]*""")                                               to SH_COMMENT,
    Regex("""/\*[\s\S]*?\*/""")                                         to SH_COMMENT,
    Regex(""""[^"]*"""")                                                to SH_STRING,
    Regex("""'[^'\\]'""")                                               to SH_STRING,
    Regex("""\b(if|else|when|for|while|do|return|break|continue|throw|try|catch|finally|in|!in|is|!is|as|as\?)\b""")
                                                                        to SH_CONTROL,
    Regex("""\b(val|var|fun|class|object|interface|data|sealed|abstract|open|override|companion|by|init|constructor|enum|typealias|operator|infix|inline|suspend|reified|external|annotation|lateinit|const|import|package)\b""")
                                                                        to SH_KEYWORD,
    Regex("""\b(true|false|null)\b""")                                  to SH_BOOL_NONE,
    Regex("""\b(Int|String|Boolean|Float|Double|Long|Char|Byte|Short|Unit|Any|Nothing|List|Map|Set|Array|Pair|Triple|lazy|println|print|readLine|TODO|error|check|require|apply|also|let|run|with)\b""")
                                                                        to SH_BUILTIN,
    Regex("""(?<=fun )\w+""")                                           to SH_FUNC_DEF,
    Regex("""(?<=class |object |interface )\w+""")                      to SH_CLASS_NAME,
    Regex("""\b\d+\.?\d*[LFf]?\b""")                                   to SH_NUMBER,
))

// ── Java ──────────────────────────────────────────────────────────────────────
private fun tokenizeJava(code: String) = tokenize(code, listOf(
    Regex("""//[^\n]*""")                                               to SH_COMMENT,
    Regex("""/\*[\s\S]*?\*/""")                                         to SH_COMMENT,
    Regex(""""[^"\\]*"""")                                              to SH_STRING,
    Regex("""'[^'\\]'""")                                               to SH_STRING,
    Regex("""\b(if|else|for|while|do|switch|case|default|return|break|continue|throw|try|catch|finally|instanceof|new|this|super)\b""")
                                                                        to SH_CONTROL,
    Regex("""\b(public|private|protected|static|final|abstract|class|interface|enum|extends|implements|import|package|void|synchronized|volatile|transient|native)\b""")
                                                                        to SH_KEYWORD,
    Regex("""\b(int|long|double|float|boolean|char|byte|short|String|Integer|Long|Double|Float|Boolean|Object|List|Map|Set|Array)\b""")
                                                                        to SH_TYPE,
    Regex("""\b(true|false|null)\b""")                                  to SH_BOOL_NONE,
    Regex("""\b(System|Math|Arrays|Collections|Optional|Stream|StringBuilder|Exception|RuntimeException|Override|Deprecated)\b""")
                                                                        to SH_BUILTIN,
    Regex("""\b\d+\.?\d*[LfFdD]?\b""")                                 to SH_NUMBER,
))

// ── HTML ──────────────────────────────────────────────────────────────────────
private fun tokenizeHTML(code: String) = tokenize(code, listOf(
    Regex("""<!--[\s\S]*?-->""")                                        to SH_COMMENT,
    Regex(""""[^"]*"|'[^']*'""")                                        to SH_STRING,
    Regex("""</?\w[\w-]*""")                                            to SH_KEYWORD,
    Regex("""\b[\w-]+=(?="[^"]*"|'[^']*')""")                          to SH_BUILTIN,
))

// ── CSS ───────────────────────────────────────────────────────────────────────
private fun tokenizeCSS(code: String) = tokenize(code, listOf(
    Regex("""/\*[\s\S]*?\*/""")                                         to SH_COMMENT,
    Regex(""""[^"]*"|'[^']*'""")                                        to SH_STRING,
    Regex("""#[\da-fA-F]{3,8}\b""")                                     to SH_NUMBER,
    Regex("""\b\d+\.?\d*(px|em|rem|%|vh|vw|pt|deg|s|ms)?\b""")        to SH_NUMBER,
    Regex("""[\w-]+(?=\s*:)""")                                         to SH_BUILTIN,
    Regex("""[.#][\w-]+""")                                             to SH_CLASS_NAME,
    Regex("""\b(important|root|hover|focus|active|before|after|not|nth-child)\b""")
                                                                        to SH_DECORATOR,
))

// ── JSON ──────────────────────────────────────────────────────────────────────
private fun tokenizeJSON(code: String) = tokenize(code, listOf(
    Regex(""""[^"]*"(?=\s*:)""")                                        to SH_KEYWORD,   // keys = blue
    Regex(""""[^"]*"""")                                                to SH_STRING,    // values = orange
    Regex("""\b(true|false|null)\b""")                                  to SH_BOOL_NONE,
    Regex("""-?\b\d+\.?\d*([eE][+-]?\d+)?\b""")                        to SH_NUMBER,
))

// ── Bash / Shell ──────────────────────────────────────────────────────────────
private fun tokenizeBash(code: String) = tokenize(code, listOf(
    Regex("""#[^\n]*""")                                                to SH_COMMENT,
    Regex(""""[^"]*"|'[^']*'""")                                        to SH_STRING,
    Regex("""\$\{?[\w]+\}?""")                                          to SH_SELF,      // variables
    Regex("""\b(if|then|else|elif|fi|for|while|do|done|case|esac|in|function|return|exit|break|continue|local|export|readonly|shift|trap|eval)\b""")
                                                                        to SH_CONTROL,
    Regex("""\b(echo|printf|read|cd|ls|mkdir|rm|cp|mv|cat|grep|sed|awk|find|chmod|chown|sudo|apt|brew|pip|git|curl|wget|ssh|scp|tar|zip|unzip|source|alias|export|set|unset)\b""")
                                                                        to SH_BUILTIN,
    Regex("""\b\d+\b""")                                                to SH_NUMBER,
))

// ── Generic (fallback) ────────────────────────────────────────────────────────
private fun tokenizeGeneric(code: String) = tokenize(code, listOf(
    Regex("""//[^\n]*|#[^\n]*|--[^\n]*""")                             to SH_COMMENT,
    Regex(""""[^"]*"|'[^']*'""")                                        to SH_STRING,
    Regex("""\b\d+\.?\d*\b""")                                          to SH_NUMBER,
))
