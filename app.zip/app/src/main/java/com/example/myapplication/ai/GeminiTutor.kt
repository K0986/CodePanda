package com.example.myapplication.ai

import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GeminiTutor(
    private val apiKey: String = API_KEY
) {
    companion object {
        private const val TAG = "GeminiTutor"
        private const val API_KEY = "AQ.Ab8RN6JCtnWUKhnPrVNz5-JR53qTyyvRd5CQRjFGL6IC8eyyWg"
        
        // Models in order of preference
        private val MODELS = listOf(
            "gemini-3.8-flash",      // Primary: Best quality/speed balance
            "gemini-3.7-flash",      // Backup: Good reliability
            "gemini-3.5-flash-lite"  // Feature/Emergency: Ultra-fast, basic
        )
    }

    private val config = generationConfig {
        temperature = 0.7f
        topK = 40
        topP = 0.95f
        maxOutputTokens = 1024
    }

    /**
     * Tries to generate content using a fallback mechanism across multiple models.
     */
    private suspend fun generateWithFallback(prompt: String): String = withContext(Dispatchers.IO) {
        var lastError: Exception? = null
        
        for (modelName in MODELS) {
            try {
                Log.d(TAG, "Attempting request with model: $modelName")
                val model = GenerativeModel(
                    modelName = modelName,
                    apiKey = apiKey,
                    generationConfig = config
                )
                val response = model.generateContent(prompt)
                val text = response.text
                if (text != null) {
                    Log.d(TAG, "Successfully generated content with $modelName")
                    return@withContext text
                }
            } catch (e: Exception) {
                Log.w(TAG, "Model $modelName failed: ${e.message}")
                lastError = e
            }
        }
        
        Log.e(TAG, "All AI models failed. Last error: ${lastError?.message}")
        throw lastError ?: Exception("All models failed to respond.")
    }

    suspend fun getExplanation(lessonTopic: String, userQuestion: String): String? =
        try {
            val prompt = buildTutorPrompt(lessonTopic, userQuestion)
            generateWithFallback(prompt)
        } catch (e: Exception) {
            "⚠️ AI Error: ${e.localizedMessage ?: "Could not reach the AI Tutor fallback chain."}"
        }

    suspend fun runCode(language: String, code: String): String =
        try {
            val prompt = """
                You are a $language code interpreter. Run this code and return ONLY the output:
                
                ```$language
                $code
                ```
                
                Rules:
                - Return ONLY what would be printed/returned
                - If there's a syntax/runtime error, show the error message
                - For input() calls, use "Python Hero" as default input
                - No explanations, no markdown, just raw output
            """.trimIndent()
            
            generateWithFallback(prompt)
        } catch (e: Exception) {
            "Error: ${e.message}"
        }

    private fun buildTutorPrompt(topic: String, question: String): String = """
        You are an AI Programming Tutor in 'Python Hero' — a gamified coding app.
        Topic: $topic
        User question: $question
        
        Be friendly and encouraging. Use a code example if helpful.
        Format code with backticks.
    """.trimIndent()
}
