package com.example.myapplication.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.myapplication.data.AllCoursesData
import com.example.myapplication.data.CourseCategory
import com.example.myapplication.model.Course
import com.example.myapplication.ui.components.*
import com.example.myapplication.ui.theme.*
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.model.UserProgress
import com.example.myapplication.viewmodel.UserProgressViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onCourseClick: (Course) -> Unit,
    onSearchClick: () -> Unit = {},
    onMenuClick: () -> Unit = {},
    progressViewModel: UserProgressViewModel = viewModel(),
    onContinueLearning: (String) -> Unit = {},
    onBottomNavSelected: (NavTab) -> Unit = {}
) {
    val progress by progressViewModel.progress.collectAsState()
    val coursesProgress by progressViewModel.coursesProgress.collectAsState()
    val lastActiveCourseId by progressViewModel.lastActiveCourseId.collectAsState()

    HomeScreenContent(
        progress = progress,
        coursesProgress = coursesProgress,
        lastActiveCourseId = lastActiveCourseId,
        onCourseClick = onCourseClick,
        onSearchClick = onSearchClick,
        onMenuClick = onMenuClick,
        onContinueLearning = onContinueLearning,
        onBottomNavSelected = onBottomNavSelected
    )
}

@Composable
fun HomeScreenContent(
    progress: UserProgress,
    coursesProgress: Map<String, Float>,
    lastActiveCourseId: String,
    onCourseClick: (Course) -> Unit,
    onSearchClick: () -> Unit = {},
    onMenuClick: () -> Unit = {},
    onContinueLearning: (String) -> Unit = {},
    onBottomNavSelected: (NavTab) -> Unit = {}
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    // Responsive: check screen width
    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(DeepSpace)) {
        val isTablet = maxWidth >= 600.dp
        val columns = if (isTablet) 3 else 2

        // ── AI Chat State ────────────────────────────────────────────────
        var chatOpen by remember { mutableStateOf(false) }
        var chatInput by remember { mutableStateOf("") }
        val chatMessages = remember { mutableStateListOf<AiChatMessage>() }
        var isAiTyping by remember { mutableStateOf(false) }
        val coroutineScope = rememberCoroutineScope()
        val gemini = remember { com.example.myapplication.ai.GeminiTutor() }
        val listState = androidx.compose.foundation.lazy.rememberLazyListState()

        Scaffold(
            containerColor = DeepSpace,
            floatingActionButton = {
                AiChatFab(
                    hasUnread = chatMessages.isEmpty(),
                    onClick = { chatOpen = true }
                )
            },
            bottomBar = {
                if (!isTablet) {
                    BottomNavBar(
                        selectedTab = selectedTab,
                        onTabSelected = {
                            selectedTab = it
                            NavTab.entries.getOrNull(it)?.let(onBottomNavSelected)
                        }
                    )
                }
            }
        ) { padding ->
            Row(modifier = Modifier.fillMaxSize()) {
                // Rail nav for tablets
                if (isTablet) {
                    TabletRailNav(
                        selectedTab = selectedTab,
                        onTabSelected = {
                            selectedTab = it
                            NavTab.entries.getOrNull(it)?.let(onBottomNavSelected)
                        }
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .padding(padding)
                        .fillMaxSize()
                        .background(DeepSpace),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    // Top bar with hamburger
                    item {
                        HomeTopBar(
                            streak = progress.streak,
                            xp = progress.xp,
                            heartsLeft = progress.heartsLeft,
                            maxHearts = progress.maxHearts,
                            onMenuClick = onMenuClick,
                            onSearchClick = onSearchClick
                        )
                    }

                    // Daily Challenge Card
                    item {
                        DailyChallengeCard(onCourseClick = onCourseClick)
                    }

                    // Daily Goal
                    item {
                        DailyGoalCard(
                            dailyXpEarned = progress.dailyXpEarned,
                            dailyXpGoal = progress.dailyXpGoal,
                            goalProgress = progress.dailyGoalProgress
                        )
                    }

                    // Continue Learning — dynamic based on last active course
                    item {
                        val startedCourses = AllCoursesData.allCourses.filter {
                            (coursesProgress[it.id] ?: 0f) > 0f
                        }
                        if (startedCourses.isNotEmpty()) {
                            val activeCourse = startedCourses.find { it.id == lastActiveCourseId }
                                ?: startedCourses.first()
                            val pct = ((coursesProgress[activeCourse.id] ?: 0f) * 100).toInt()
                            Spacer(Modifier.height(12.dp))
                            SectionLabel("CONTINUE LEARNING 🚀")
                            Spacer(Modifier.height(8.dp))
                            ContinueLearningCard(
                                course = activeCourse,
                                progressPct = pct,
                                onClick = { onContinueLearning(activeCourse.id) }
                            )
                        } else {
                            Spacer(Modifier.height(12.dp))
                            SectionLabel("START LEARNING 🚀")
                            Spacer(Modifier.height(8.dp))
                            HeroCourseCard(
                                course = AllCoursesData.python,
                                onClick = { onCourseClick(AllCoursesData.python) }
                            )
                        }
                    }

                    // All categories
                    items(AllCoursesData.categories) { category ->
                        CourseCategorySection(
                            category = category,
                            columns = columns,
                            coursesProgress = coursesProgress,
                            onCourseClick = onCourseClick
                        )
                    }
                }
            }
        }

        // ── AI Chat Overlay ─────────────────────────────────────────────
        if (chatOpen) {
            AiChatOverlay(
                messages = chatMessages,
                input = chatInput,
                isTyping = isAiTyping,
                listState = listState,
                onInputChange = { chatInput = it },
                onSend = {
                    val userMsg = chatInput.trim()
                    if (userMsg.isNotBlank() && !isAiTyping) {
                        chatMessages.add(AiChatMessage(userMsg, isUser = true))
                        chatInput = ""
                        isAiTyping = true
                        coroutineScope.launch {
                            listState.animateScrollToItem(chatMessages.size - 1)
                            val reply = gemini.getExplanation("Python Programming", userMsg)
                                ?: "Sorry, I couldn't get a response. Please try again."
                            chatMessages.add(AiChatMessage(reply, isUser = false))
                            isAiTyping = false
                            listState.animateScrollToItem(chatMessages.size - 1)
                        }
                    }
                },
                onClose = { chatOpen = false }
            )
        }
    }
}

@Composable
fun HomeTopBar(
    streak: Int, xp: Int, heartsLeft: Int, maxHearts: Int,
    onMenuClick: () -> Unit, onSearchClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepSpace)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Hamburger
        IconButton(
            onClick = onMenuClick,
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceDark)
        ) {
            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary)
        }

        Spacer(Modifier.width(10.dp))

        // Logo
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(VioletLight, ElectricViolet))),
                contentAlignment = Alignment.Center
            ) { Text("🐍", fontSize = 16.sp) }
            Spacer(Modifier.width(6.dp))
            Text("Python Hero", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = TextPrimary)
        }

        // Search icon
        IconButton(
            onClick = onSearchClick,
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceDark)
        ) {
            Icon(Icons.Default.Search, contentDescription = "Search", tint = TextPrimary)
        }

        Spacer(Modifier.width(8.dp))

        // GET PRO button
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.Transparent,
            border = BorderStroke(1.dp, Color(0xFFEA580C))
        ) {
            Box(
                modifier = Modifier
                    .background(Brush.horizontalGradient(listOf(Color(0xFFEA580C), Color(0xFFDC2626))))
                    .padding(horizontal = 14.dp, vertical = 7.dp)
            ) {
                Text("GET PRO", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, letterSpacing = 0.5.sp)
            }
        }
    }

    // HUD row
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DeepSpace)
            .padding(horizontal = 16.dp)
            .padding(bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        StreakBadge(streak = streak)
        XpBadge(xp = xp)
        Spacer(Modifier.weight(1f))
        HeartBar(heartsLeft = heartsLeft, maxHearts = maxHearts)
    }
}

@Composable
fun DailyChallengeCard(onCourseClick: (Course) -> Unit) {
    val pulseAnim by rememberInfiniteTransition(label = "challenge").animateFloat(
        0.95f, 1f,
        infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Card(
        onClick = { onCourseClick(AllCoursesData.python) },
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.horizontalGradient(listOf(Color(0xFFF59E0B), Color(0xFFEA580C))))
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("⚡", fontSize = 28.sp, modifier = Modifier.graphicsLayer { scaleX = pulseAnim; scaleY = pulseAnim })
                Spacer(Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("DAILY CHALLENGE", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold,
                        color = Color.White.copy(0.8f), letterSpacing = 1.sp)
                    Text("Complete a Python quiz", fontWeight = FontWeight.ExtraBold, color = Color.White, fontSize = 15.sp)
                    Text("+50 Bonus XP 🎯", color = Color.White.copy(0.85f), fontSize = 12.sp)
                }
                Surface(shape = RoundedCornerShape(12.dp), color = Color.White.copy(0.25f)) {
                    Text("START", modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun CourseCategorySection(
    category: CourseCategory,
    columns: Int,
    coursesProgress: Map<String, Float> = emptyMap(),
    onCourseClick: (Course) -> Unit
) {
    Column {
        Spacer(Modifier.height(16.dp))
        SectionLabel(category.title)
        Spacer(Modifier.height(10.dp))

        // Grid
        val chunked = category.courses.chunked(columns)
        chunked.forEachIndexed { rowIdx, row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                row.forEachIndexed { colIdx, course ->
                    val courseWithProgress = course.copy(
                        progress = maxOf(course.progress, coursesProgress[course.id] ?: 0f)
                    )
                    CategoryCourseCard(
                        course = courseWithProgress,
                        modifier = Modifier.weight(1f),
                        animDelay = (rowIdx * columns + colIdx) * 80,
                        onClick = { onCourseClick(courseWithProgress) }
                    )
                }
                repeat(columns - row.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun CategoryCourseCard(
    course: Course,
    modifier: Modifier = Modifier,
    animDelay: Int = 0,
    onClick: () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    val gradStart = Color(course.gradientStart)
    val gradEnd = Color(course.gradientEnd)

    LaunchedEffect(Unit) {
        delay(animDelay.toLong())
        visible = true
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(initialOffsetY = { it / 2 }, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
        modifier = modifier
    ) {
        Card(
            onClick = onClick,
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(Brush.verticalGradient(listOf(gradStart, gradEnd)))
                    .padding(12.dp)
            ) {
                // NEW / TRENDING badge
                when {
                    course.trending -> Surface(
                        shape = RoundedCornerShape(6.dp), color = Color(0xFFF59E0B),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text("TRENDING", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF1A1035), letterSpacing = 0.5.sp,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                    course.isNew -> Surface(
                        shape = RoundedCornerShape(6.dp), color = NeonCyan.copy(0.9f),
                        modifier = Modifier.align(Alignment.TopStart)
                    ) {
                        Text("NEW", fontSize = 9.sp, fontWeight = FontWeight.ExtraBold,
                            color = DeepSpace, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                    }
                }

                // Progress indicator
                if (course.progress > 0f) {
                    Row(
                        modifier = Modifier.align(Alignment.TopEnd),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            progress = { course.progress },
                            modifier = Modifier.size(20.dp),
                            color = Color.White,
                            trackColor = Color.White.copy(0.3f),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("${(course.progress*100).toInt()}%", fontSize = 9.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                // Animated logo
                Box(modifier = Modifier.align(Alignment.Center).size(56.dp)) {
                    CourseLogo(courseId = course.id, size = 56.dp)
                }

                // Title at bottom
                Column(modifier = Modifier.align(Alignment.BottomStart)) {
                    Text(course.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}

@Composable
fun TabletRailNav(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    NavigationRail(
        containerColor = SurfaceDark,
        contentColor = ElectricViolet,
        modifier = Modifier.fillMaxHeight()
    ) {
        Spacer(Modifier.height(16.dp))
        NavTab.entries.forEachIndexed { index, tab ->
            val isSelected = selectedTab == index
            NavigationRailItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = { Icon(if (isSelected) tab.selectedIcon else tab.icon, tab.label) },
                label = { Text(tab.label, fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = ElectricViolet,
                    selectedTextColor = ElectricViolet,
                    unselectedIconColor = TextMuted,
                    indicatorColor = ElectricViolet.copy(0.15f)
                )
            )
        }
    }
}

enum class NavTab(
    val label: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector
) {
    Home("Home", Icons.Outlined.Home, Icons.Filled.Home),
    Courses("Courses", Icons.Outlined.School, Icons.Filled.School),
    Ranks("Ranks", Icons.Outlined.EmojiEvents, Icons.Filled.EmojiEvents),
    Code("Code", Icons.Outlined.Code, Icons.Filled.Code)
}

@Composable
fun BottomNavBar(selectedTab: Int, onTabSelected: (Int) -> Unit) {
    NavigationBar(containerColor = SurfaceDark, tonalElevation = 0.dp) {
        NavTab.entries.forEachIndexed { index, tab ->
            val isSelected = selectedTab == index
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(index) },
                icon = { Icon(if (isSelected) tab.selectedIcon else tab.icon, tab.label) },
                label = { Text(tab.label, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ElectricViolet,
                    selectedTextColor = ElectricViolet,
                    unselectedIconColor = TextMuted,
                    indicatorColor = ElectricViolet.copy(0.15f)
                )
            )
        }
    }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = TextSecondary,
        letterSpacing = 1.sp,
        modifier = Modifier.padding(horizontal = 16.dp)
    )
}

@Composable
fun DailyGoalCard(dailyXpEarned: Int, dailyXpGoal: Int, goalProgress: Float) {
    val animProgress by animateFloatAsState(
        targetValue = goalProgress,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "goalAnim"
    )
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        border = BorderStroke(1.dp, SurfaceVariantDark)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circular ring
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(52.dp)) {
                CircularProgressIndicator(
                    progress = { animProgress },
                    modifier = Modifier.fillMaxSize(),
                    color = NeonCyan,
                    trackColor = SurfaceVariantDark,
                    strokeWidth = 4.dp
                )
                Text("🎯", fontSize = 20.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Daily Goal", fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 14.sp)
                Text("$dailyXpEarned / $dailyXpGoal XP", color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { animProgress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = NeonCyan,
                    trackColor = SurfaceVariantDark
                )
            }
        }
    }
}

@Composable
fun HeroCourseCard(course: Course, onClick: () -> Unit) {
    val gradStart = Color(course.gradientStart)
    val gradEnd = Color(course.gradientEnd)
    val infiniteTransition = rememberInfiniteTransition(label = "heroGlow")
    val glowAlpha by infiniteTransition.animateFloat(
        0.4f, 0.9f,
        infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Box(modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)) {
        // Glow blob
        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(24.dp)
                .alpha(glowAlpha * 0.5f)
                .background(Brush.horizontalGradient(listOf(gradStart, gradEnd)), RoundedCornerShape(24.dp))
        )
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Brush.horizontalGradient(listOf(gradStart, gradEnd)))
                    .padding(20.dp)
            ) {
                // Animated logo on right
                Box(modifier = Modifier.align(Alignment.CenterEnd).size(90.dp)) {
                    CourseLogo(courseId = course.id, size = 90.dp)
                }
                Column(modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth(0.65f)) {
                    Text(course.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("${(course.progress * 100).toInt()}% Complete", color = Color.White.copy(0.75f), fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = RoundedCornerShape(20.dp), color = Color.White.copy(0.25f)) {
                        Text(
                            "START ▶",
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ContinueLearningCard(course: Course, progressPct: Int, onClick: () -> Unit) {
    val gradStart = Color(course.gradientStart)
    val gradEnd = Color(course.gradientEnd)
    val infiniteTransition = rememberInfiniteTransition(label = "contGlow")
    val glowAlpha by infiniteTransition.animateFloat(
        0.4f, 1f,
        infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )

    Box(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .blur(20.dp)
                .alpha(glowAlpha * 0.5f)
                .background(Brush.horizontalGradient(listOf(gradStart, gradEnd)), RoundedCornerShape(24.dp))
        )
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(gradStart, gradEnd)))
                    .padding(20.dp)
            ) {
                Box(modifier = Modifier.align(Alignment.CenterEnd).size(80.dp)) {
                    CourseLogo(courseId = course.id, size = 80.dp)
                }
                Column(modifier = Modifier.align(Alignment.TopStart).fillMaxWidth(0.65f)) {
                    // "Continue where you left off" badge
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White.copy(0.2f)
                    ) {
                        Text(
                            "📍 Continue where you left off",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(course.title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Spacer(Modifier.height(6.dp))
                    // Progress bar
                    LinearProgressIndicator(
                        progress = { progressPct / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = Color.White,
                        trackColor = Color.White.copy(0.3f)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text("$progressPct% Complete", color = Color.White.copy(0.8f), fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Surface(shape = RoundedCornerShape(20.dp), color = Color.White.copy(0.25f)) {
                        Text(
                            "CONTINUE ▶",
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    MyApplicationTheme {
        HomeScreenContent(
            progress = UserProgress(
                xp = 150,
                level = 2,
                streak = 5,
                heartsLeft = 3,
                maxHearts = 5,
                dailyXpEarned = 25,
                dailyXpGoal = 50
            ),
            coursesProgress = mapOf("python" to 0.45f),
            lastActiveCourseId = "python",
            onCourseClick = {},
            onSearchClick = {},
            onMenuClick = {},
            onContinueLearning = {},
            onBottomNavSelected = {}
        )
    }
}

// ── AI Chat Data ────────────────────────────────────────────────────────────
data class AiChatMessage(val text: String, val isUser: Boolean)

// ── Animated Robot FAB ──────────────────────────────────────────────────────
@Composable
fun AiChatFab(hasUnread: Boolean, onClick: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "fabPulse")
    val glowScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.12f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glow"
    )
    val eyeAnim by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2000), RepeatMode.Restart),
        label = "eye"
    )

    Box(
        modifier = Modifier
            .padding(bottom = 8.dp, end = 4.dp)
            .size(64.dp),
        contentAlignment = Alignment.Center
    ) {
        // Outer glow ring
        Box(
            modifier = Modifier
                .size(64.dp)
                .scale(glowScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(NeonCyan.copy(alpha = 0.35f), ElectricViolet.copy(alpha = 0.2f), Color.Transparent)
                    )
                )
        )
        // FAB button
        FloatingActionButton(
            onClick = onClick,
            containerColor = Color.Transparent,
            contentColor = Color.White,
            shape = CircleShape,
            modifier = Modifier.size(56.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF7C3AED), Color(0xFF06B6D4))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Robot face drawn with Canvas
                Canvas(modifier = Modifier.size(36.dp)) {
                    val w = size.width
                    val h = size.height
                    // Head outline circle (already drawn by FAB)
                    // Antenna
                    drawLine(
                        color = Color.White,
                        start = androidx.compose.ui.geometry.Offset(w / 2, h * 0.05f),
                        end = androidx.compose.ui.geometry.Offset(w / 2, h * 0.25f),
                        strokeWidth = 3f
                    )
                    drawCircle(
                        color = NeonCyan,
                        radius = 5f,
                        center = androidx.compose.ui.geometry.Offset(w / 2, h * 0.04f)
                    )
                    // Eyes — blink based on eyeAnim
                    val eyeHeight = if (eyeAnim > 0.92f) 2f else 9f
                    drawRoundRect(
                        color = NeonCyan,
                        topLeft = androidx.compose.ui.geometry.Offset(w * 0.22f, h * 0.32f),
                        size = androidx.compose.ui.geometry.Size(w * 0.18f, eyeHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f)
                    )
                    drawRoundRect(
                        color = NeonCyan,
                        topLeft = androidx.compose.ui.geometry.Offset(w * 0.6f, h * 0.32f),
                        size = androidx.compose.ui.geometry.Size(w * 0.18f, eyeHeight),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f)
                    )
                    // Mouth
                    drawRoundRect(
                        color = Color.White.copy(alpha = 0.8f),
                        topLeft = androidx.compose.ui.geometry.Offset(w * 0.28f, h * 0.65f),
                        size = androidx.compose.ui.geometry.Size(w * 0.44f, h * 0.12f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f)
                    )
                }
            }
        }
    }
}

// ── AI Chat Overlay ─────────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiChatOverlay(
    messages: List<AiChatMessage>,
    input: String,
    isTyping: Boolean,
    listState: LazyListState,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onClose: () -> Unit
) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.6f)),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Dismiss tap outside
            Box(modifier = Modifier.fillMaxSize().clickable { onClose() })

            // Chat panel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.85f)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFF1A0A2E), Color(0xFF0D1117))
                        )
                    )
                    .clickable(enabled = false) {}
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF7C3AED), Color(0xFF06B6D4))
                                )
                            )
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Mini robot icon
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🤖", fontSize = 20.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Python Hero AI",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                            Text(
                                if (isTyping) "Thinking..." else "Ask me anything!",
                                color = Color.White.copy(0.75f),
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, null, tint = Color.White)
                        }
                    }

                    // Messages list
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (messages.isEmpty()) {
                            item {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("🤖", fontSize = 48.sp)
                                    Spacer(Modifier.height(12.dp))
                                    Text(
                                        "Hi! I'm your Python Hero AI tutor.\nAsk me anything about Python!",
                                        color = TextSecondary,
                                        textAlign = TextAlign.Center,
                                        fontSize = 14.sp
                                    )
                                    Spacer(Modifier.height(16.dp))
                                    // Quick prompts
                                    listOf("What is a list?", "Explain loops", "What are functions?").forEach { prompt ->
                                        Surface(
                                            onClick = { onInputChange(prompt) },
                                            shape = RoundedCornerShape(20.dp),
                                            color = ElectricViolet.copy(0.2f),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, ElectricViolet.copy(0.4f)),
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                        ) {
                                            Text(
                                                prompt,
                                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                                color = TextPrimary,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        items(messages) { msg ->
                            AiChatBubble(msg)
                        }
                        if (isTyping) {
                            item { TypingIndicator() }
                        }
                    }

                    // Input row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF12091E))
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = onInputChange,
                            placeholder = { Text("Ask about Python...", color = TextMuted, fontSize = 14.sp) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(24.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = SurfaceVariantDark,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = NeonCyan
                            ),
                            maxLines = 3,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { onSend() }),
                            enabled = !isTyping
                        )
                        Spacer(Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    if (input.isNotBlank() && !isTyping)
                                        Brush.linearGradient(listOf(Color(0xFF7C3AED), NeonCyan))
                                    else
                                        Brush.linearGradient(listOf(SurfaceVariantDark, SurfaceVariantDark))
                                )
                                .clickable(enabled = input.isNotBlank() && !isTyping) { onSend() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Send, null, tint = if (input.isNotBlank() && !isTyping) Color.White else TextMuted)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AiChatBubble(msg: AiChatMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!msg.isUser) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF7C3AED), NeonCyan))),
                contentAlignment = Alignment.Center
            ) {
                Text("🤖", fontSize = 14.sp)
            }
            Spacer(Modifier.width(8.dp))
        }

        if (msg.isUser) {
            // User bubble — plain text, purple gradient
            Box(
                modifier = Modifier
                    .widthIn(max = 280.dp)
                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 4.dp, bottomStart = 18.dp, bottomEnd = 18.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF7C3AED), Color(0xFF5B21B6))))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Text(msg.text, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp)
            }
        } else {
            // AI bubble — parse markdown code blocks
            Column(
                modifier = Modifier.widthIn(max = 300.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                parseMessageSegments(msg.text).forEach { segment ->
                    when (segment) {
                        is MessageSegment.PlainText -> {
                            if (segment.text.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp))
                                        .background(Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF1A1A2E))))
                                        .border(1.dp, SurfaceVariantDark, RoundedCornerShape(4.dp, 18.dp, 18.dp, 18.dp))
                                        .padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Text(segment.text.trim(), color = TextPrimary, fontSize = 14.sp, lineHeight = 20.sp)
                                }
                            }
                        }
                        is MessageSegment.CodeBlock -> {
                            CodeSnippetBlock(language = segment.language, code = segment.code)
                        }
                    }
                }
            }
        }
    }
}

// ── Segment model ────────────────────────────────────────────────────────────
sealed class MessageSegment {
    data class PlainText(val text: String) : MessageSegment()
    data class CodeBlock(val language: String, val code: String) : MessageSegment()
}

fun parseMessageSegments(text: String): List<MessageSegment> {
    val segments = mutableListOf<MessageSegment>()
    val regex = Regex("```(\\w*)\\n?([\\s\\S]*?)```")
    var lastEnd = 0
    regex.findAll(text).forEach { match ->
        if (match.range.first > lastEnd) {
            segments.add(MessageSegment.PlainText(text.substring(lastEnd, match.range.first)))
        }
        val lang = match.groupValues[1].ifBlank { "code" }
        val code = match.groupValues[2]
        segments.add(MessageSegment.CodeBlock(language = lang, code = code))
        lastEnd = match.range.last + 1
    }
    if (lastEnd < text.length) {
        segments.add(MessageSegment.PlainText(text.substring(lastEnd)))
    }
    return segments.ifEmpty { listOf(MessageSegment.PlainText(text)) }
}

// ── ChatGPT-style Code Block ─────────────────────────────────────────────────
@Composable
fun CodeSnippetBlock(language: String, code: String) {
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF30363D), RoundedCornerShape(12.dp))
    ) {
        // ── Header bar ───────────────────────────────────────────
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF161B22))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Language pill
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(NeonCyan)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    language.lowercase(),
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            // Copy button
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .clickable {
                        clipboardManager.setText(
                            androidx.compose.ui.text.AnnotatedString(code)
                        )
                        copied = true
                    }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (copied) Icons.Default.Check else Icons.Default.ContentCopy,
                    contentDescription = null,
                    tint = if (copied) CorrectGreen else TextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(Modifier.width(4.dp))
                Text(
                    if (copied) "Copied!" else "Copy code",
                    fontSize = 12.sp,
                    color = if (copied) CorrectGreen else TextSecondary
                )
            }
            // Reset copied after 2s
            if (copied) {
                LaunchedEffect(Unit) {
                    delay(2000)
                    copied = false
                }
            }
        }

        // ── Code area ────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0D1117))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            val highlighted = remember(code, language) {
                highlightCode(code.trimEnd(), language)
            }
            Text(
                text = highlighted,
                fontSize = 13.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                lineHeight = 20.sp,
                softWrap = false
            )
        }
    }
}


@Composable
fun TypingIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "typing")
    val dot1 by infiniteTransition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(500), RepeatMode.Reverse), label = "d1")
    val dot2 by infiniteTransition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(500, delayMillis = 150), RepeatMode.Reverse), label = "d2")
    val dot3 by infiniteTransition.animateFloat(0.3f, 1f, infiniteRepeatable(tween(500, delayMillis = 300), RepeatMode.Reverse), label = "d3")
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF1E1B4B))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        listOf(dot1, dot2, dot3).forEach { alpha ->
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(NeonCyan.copy(alpha = alpha))
            )
        }
    }
}
