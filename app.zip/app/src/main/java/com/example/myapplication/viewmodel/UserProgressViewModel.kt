package com.example.myapplication.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.FirestoreRepository
import com.example.myapplication.model.UserProgress
import com.example.myapplication.model.XpGain
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.retryWhen
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class UserProgressViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application
    private val auth = FirebaseAuth.getInstance()
    private var prefs = application.getSharedPreferences(
        "python_hero_prefs_${auth.currentUser?.uid ?: "guest"}",
        Context.MODE_PRIVATE
    )

    // ── Core state ────────────────────────────────────────────────────────────
    private val _progress = MutableStateFlow(loadProgressLocal())
    val progress: StateFlow<UserProgress> = _progress.asStateFlow()

    private val _username = MutableStateFlow(prefs.getString("username", "") ?: "")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _photoUrl = MutableStateFlow(prefs.getString("photoUrl", "") ?: "")
    val photoUrl: StateFlow<String> = _photoUrl.asStateFlow()

    private val _coursesProgress = MutableStateFlow<Map<String, Float>>(loadCoursesProgressLocal())
    val coursesProgress: StateFlow<Map<String, Float>> = _coursesProgress.asStateFlow()

    // Last active course/lesson for "Continue Learning"
    private val _lastActiveCourseId = MutableStateFlow(prefs.getString("lastActiveCourseId", "") ?: "")
    val lastActiveCourseId: StateFlow<String> = _lastActiveCourseId.asStateFlow()

    private val _lastActiveLessonId = MutableStateFlow(prefs.getString("lastActiveLessonId", "") ?: "")
    val lastActiveLessonId: StateFlow<String> = _lastActiveLessonId.asStateFlow()

    // Photo upload state
    private val _photoUploadState = MutableStateFlow<PhotoUploadState>(PhotoUploadState.Idle)
    val photoUploadState: StateFlow<PhotoUploadState> = _photoUploadState.asStateFlow()

    private val _syncState = MutableStateFlow<SyncState>(SyncState.Idle)
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    // Events
    private val _xpGainEvent = MutableStateFlow<XpGain?>(null)
    val xpGainEvent: StateFlow<XpGain?> = _xpGainEvent.asStateFlow()

    private val _heartLostEvent = MutableStateFlow(false)
    val heartLostEvent: StateFlow<Boolean> = _heartLostEvent.asStateFlow()

    private val syncMutex = Mutex()
    private var listenerJob: Job? = null
    private var pendingSyncJob: Job? = null
    private var activeUid: String? = null

    init {
        if (auth.currentUser != null) {
            onUserLoggedIn()
        }
    }

    // ── Login / Sync entry point ───────────────────────────────────────────────
    fun onUserLoggedIn() {
        val id = auth.currentUser?.uid ?: return
        if (activeUid == id && listenerJob?.isActive == true) return

        listenerJob?.cancel()
        activeUid = id
        prefs = app.getSharedPreferences("python_hero_prefs_$id", Context.MODE_PRIVATE)
        restoreLocalState()
        listenerJob = viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            try {
                val p = _progress.value
                val remote = FirestoreRepository.fetchAndMergeUserData(
                    localXp = p.xp, localLevel = p.level, localStreak = p.streak,
                    localHearts = p.heartsLeft, localDailyXp = p.dailyXpEarned,
                    localLessonsCompleted = p.totalLessonsCompleted,
                    localCompletedIds = p.completedLessonIds,
                    localCoursesProgress = _coursesProgress.value
                )
                remote?.let(::applyRemoteData)
                // Persist the merged local + remote state. Firestore queues this
                // write offline, so a first login never drops local progress.
                saveAndSync()
                _syncState.value = SyncState.Synced

                // One collector per authenticated uid. Retry transient listener
                // failures instead of silently leaving the app permanently stale.
                FirestoreRepository.userDataFlow()
                    .retryWhen { cause, attempt ->
                        _syncState.value = SyncState.Error
                        val retryable = cause !is FirebaseFirestoreException ||
                            cause.code == FirebaseFirestoreException.Code.UNAVAILABLE ||
                            cause.code == FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ||
                            cause.code == FirebaseFirestoreException.Code.ABORTED
                        if (!retryable || attempt >= 5) return@retryWhen false
                        delay(2_000)
                        currentCoroutineContext().isActive
                    }
                    .collect { data ->
                        if (data == null) return@collect
                        applyRemoteData(data)
                        _syncState.value = SyncState.Synced
                    }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("UserProgressVM", "Realtime sync stopped", e)
                _syncState.value = SyncState.Error
            }
        }
    }

    fun onUserLoggedOut() {
        pendingSyncJob?.cancel()
        listenerJob?.cancel()
        pendingSyncJob = null
        listenerJob = null
        activeUid = null
        prefs = app.getSharedPreferences("python_hero_prefs_guest", Context.MODE_PRIVATE)
        _progress.value = UserProgress()
        _username.value = ""
        _photoUrl.value = ""
        _coursesProgress.value = emptyMap()
        _lastActiveCourseId.value = ""
        _lastActiveLessonId.value = ""
        _syncState.value = SyncState.Idle
    }

    /**
     * Switch the local cache before reading or writing anything for a new
     * account. This prevents account A's offline progress leaking into account
     * B during the login transition.
     */
    private fun restoreLocalState() {
        _progress.value = loadProgressLocal()
        _username.value = prefs.getString("username", "") ?: ""
        _photoUrl.value = prefs.getString("photoUrl", "") ?: ""
        _coursesProgress.value = loadCoursesProgressLocal()
        _lastActiveCourseId.value = prefs.getString("lastActiveCourseId", "") ?: ""
        _lastActiveLessonId.value = prefs.getString("lastActiveLessonId", "") ?: ""
    }

    private fun applyRemoteData(data: Map<String, Any>) {
        Log.d("UserProgressVM", "Realtime update received")

        val name = data["username"] as? String ?: ""
        if (name.isNotBlank()) {
            _username.value = name
            prefs.edit().putString("username", name).apply()
        }

        val photo = data["photoUrl"] as? String ?: ""
        if (photo.isNotBlank() && _photoUploadState.value !is PhotoUploadState.Uploading) {
            _photoUrl.value = photo
            prefs.edit().putString("photoUrl", photo).apply()
        }

        val courseId = data["lastActiveCourseId"] as? String ?: ""
        val lessonId = data["lastActiveLessonId"] as? String ?: ""
        if (courseId.isNotBlank()) _lastActiveCourseId.value = courseId
        if (lessonId.isNotBlank()) _lastActiveLessonId.value = lessonId
        prefs.edit()
            .putString("lastActiveCourseId", _lastActiveCourseId.value)
            .putString("lastActiveLessonId", _lastActiveLessonId.value)
            .apply()

        val cloudCompletedIds = (data["completedLessonIds"] as? List<*>)
            ?.filterIsInstance<String>()
            ?.toSet()
            ?: emptySet()
        _progress.update { current ->
            val cloudXp = numberAsInt(data["xp"], 0)
            current.copy(
                xp = maxOf(cloudXp, current.xp),
                level = maxOf(numberAsInt(data["level"], 1), (cloudXp / 100) + 1, current.level),
                streak = numberAsInt(data["streak"], current.streak).coerceAtLeast(1),
                heartsLeft = numberAsInt(data["heartsLeft"], current.heartsLeft)
                    .coerceIn(0, current.maxHearts),
                dailyXpEarned = maxOf(numberAsInt(data["dailyXpEarned"], 0), current.dailyXpEarned),
                totalLessonsCompleted = maxOf(
                    numberAsInt(data["totalLessonsCompleted"], 0),
                    current.totalLessonsCompleted
                ),
                completedLessonIds = cloudCompletedIds + current.completedLessonIds
            )
        }

        @Suppress("UNCHECKED_CAST")
        val cpRaw = data["coursesProgress"] as? Map<String, Any> ?: emptyMap()
        val cloudProgress = cpRaw.mapValues { (_, value) ->
            numberAsFloat(value, 0f).coerceIn(0f, 1f)
        }
        _coursesProgress.update { local ->
            (local.keys + cloudProgress.keys).associateWith { key ->
                maxOf(local[key] ?: 0f, cloudProgress[key] ?: 0f)
            }
        }

        saveProgressLocal()
        saveCoursesProgressLocal()
    }

    private fun numberAsInt(value: Any?, fallback: Int): Int =
        when (value) {
            is Number -> value.toInt()
            is String -> value.toIntOrNull() ?: fallback
            else -> fallback
        }

    private fun numberAsFloat(value: Any?, fallback: Float): Float =
        when (value) {
            is Number -> value.toFloat()
            is String -> value.toFloatOrNull() ?: fallback
            else -> fallback
        }

    // ── Username / Profile ────────────────────────────────────────────────────
    fun setUsername(name: String) {
        _username.value = name
        prefs.edit().putString("username", name).apply()
        viewModelScope.launch {
            try {
                FirestoreRepository.saveUserProfile(name)
            } catch (e: Exception) {
                Log.e("UserProgressVM", "Profile sync failed", e)
                _syncState.value = SyncState.Error
            }
        }
    }

    fun uploadProfilePhoto(uri: Uri) {
        _photoUploadState.value = PhotoUploadState.Uploading
        viewModelScope.launch {
            try {
                val uid = auth.currentUser?.uid
                    ?: return@launch run {
                        _photoUploadState.value = PhotoUploadState.Error("Not signed in")
                    }

                // ── Upload to Cloudinary (free, no API key needed) ──────
                val result = com.example.myapplication.data.CloudinaryUploader
                    .uploadProfilePhoto(app, uri, uid)

                if (result.isSuccess) {
                    val url = result.getOrThrow()
                    // Save URL locally + sync to Firestore
                    _photoUrl.value = url
                    prefs.edit().putString("photoUrl", url).apply()
                    FirestoreRepository.updateUserField(uid, "photoUrl", url)
                    _photoUploadState.value = PhotoUploadState.Success(url)
                } else {
                    _photoUploadState.value = PhotoUploadState.Error(
                        result.exceptionOrNull()?.message ?: "Photo upload failed."
                    )
                }
            } catch (e: Exception) {
                Log.e("UserProgressVM", "Photo upload failed", e)
                _photoUploadState.value = PhotoUploadState.Error(
                    e.message ?: "Photo upload failed. Please try again."
                )
            }
        }
    }

    /** Show the chosen image immediately while the cloud upload is in flight. */
    fun setLocalPhotoPreview(uri: Uri) {
        _photoUrl.value = uri.toString()
        prefs.edit().putString("photoUrl", uri.toString()).apply()
    }

    fun clearPhotoUploadState() { _photoUploadState.value = PhotoUploadState.Idle }

    /** Clear only this device's cache; the realtime listener will restore cloud state. */
    fun clearLocalCache() {
        prefs.edit().clear().apply()
        restoreLocalState()
        if (auth.currentUser != null) {
            listenerJob?.cancel()
            listenerJob = null
            activeUid = null
            onUserLoggedIn()
        }
    }

    // ── XP & Lessons ─────────────────────────────────────────────────────────
    fun addXp(amount: Int, reason: String = "Correct Answer!") {
        if (amount <= 0) return
        _xpGainEvent.value = XpGain(amount, reason)
        _progress.update { c ->
            val newXp = c.xp + amount
            val newLevel = (newXp / 100) + 1
            c.copy(xp = newXp, dailyXpEarned = c.dailyXpEarned + amount, level = newLevel)
        }
        saveAndSync()
    }

    fun completeLesson(lessonId: String, xpReward: Int) {
        var newlyCompleted = false
        _progress.update { c ->
            if (lessonId in c.completedLessonIds) return@update c
            newlyCompleted = true
            c.copy(
                completedLessonIds = c.completedLessonIds + lessonId,
                totalLessonsCompleted = c.totalLessonsCompleted + 1
            )
        }
        if (newlyCompleted) {
            addXp(xpReward, "Lesson Complete! 🎉")
        }
    }

    fun loseHeart() {
        _heartLostEvent.value = true
        _progress.update { c -> c.copy(heartsLeft = (c.heartsLeft - 1).coerceAtLeast(0)) }
        saveAndSync()
    }

    // ── Course progress ───────────────────────────────────────────────────────
    fun updateCourseProgress(courseId: String, progressFraction: Float, lastLessonId: String = "") {
        _coursesProgress.update { it + (courseId to progressFraction.coerceIn(0f, 1f)) }
        if (lastLessonId.isNotBlank()) {
            _lastActiveCourseId.value = courseId
            _lastActiveLessonId.value = lastLessonId
            prefs.edit().putString("lastActiveCourseId", courseId)
                .putString("lastActiveLessonId", lastLessonId).apply()
        }
        saveCoursesProgressLocal()
        saveAndSync()
    }


    // ── Events ────────────────────────────────────────────────────────────────
    fun clearXpGainEvent() { _xpGainEvent.value = null }
    fun clearHeartLostEvent() { _heartLostEvent.value = false }

    // ── Persistence ───────────────────────────────────────────────────────────
    private fun saveAndSync() {
        saveProgressLocal()
        val p = _progress.value
        val courses = _coursesProgress.value.toMap()
        val uid = auth.currentUser?.uid ?: return
        pendingSyncJob?.cancel()
        pendingSyncJob = viewModelScope.launch {
            // Coalesce bursts from quiz completion and course progress updates.
            delay(120)
            syncMutex.withLock {
                if (auth.currentUser?.uid != uid) return@withLock
                _syncState.value = SyncState.Syncing
                try {
                    FirestoreRepository.syncProgress(
                        xp = p.xp, level = p.level, streak = p.streak,
                        heartsLeft = p.heartsLeft, dailyXpEarned = p.dailyXpEarned,
                        totalLessonsCompleted = p.totalLessonsCompleted,
                        completedLessonIds = p.completedLessonIds,
                        coursesProgress = courses,
                        lastActiveCourseId = _lastActiveCourseId.value,
                        lastActiveLessonId = _lastActiveLessonId.value
                    )
                    _syncState.value = SyncState.Synced
                } catch (e: Exception) {
                    Log.e("UserProgressVM", "Progress sync failed", e)
                    _syncState.value = SyncState.Error
                }
            }
        }
    }

    private fun saveProgressLocal() {
        val p = _progress.value
        prefs.edit().apply {
            putInt("xp", p.xp); putInt("level", p.level); putInt("streak", p.streak)
            putInt("hearts", p.heartsLeft); putInt("daily_xp", p.dailyXpEarned)
            putInt("total_lessons", p.totalLessonsCompleted)
            putStringSet("completed", p.completedLessonIds)
            apply()
        }
    }

    private fun saveCoursesProgressLocal() {
        prefs.edit().apply {
            _coursesProgress.value.forEach { (id, f) -> putFloat("cp_$id", f) }
            apply()
        }
    }

    private fun loadProgressLocal() = UserProgress(
        xp = prefs.getInt("xp", 0), level = prefs.getInt("level", 1),
        streak = prefs.getInt("streak", 1), heartsLeft = prefs.getInt("hearts", 5),
        dailyXpEarned = prefs.getInt("daily_xp", 0),
        totalLessonsCompleted = prefs.getInt("total_lessons", 0),
        completedLessonIds = prefs.getStringSet("completed", emptySet()) ?: emptySet()
    )

    private fun loadCoursesProgressLocal() = prefs.all.entries
        .filter { it.key.startsWith("cp_") }
        .associate { it.key.removePrefix("cp_") to (it.value as? Float ?: 0f) }

    override fun onCleared() {
        pendingSyncJob?.cancel()
        listenerJob?.cancel()
        super.onCleared()
    }
}

sealed class PhotoUploadState {
    object Idle : PhotoUploadState()
    object Uploading : PhotoUploadState()
    data class Success(val url: String) : PhotoUploadState()
    data class Error(val message: String) : PhotoUploadState()
}

sealed class SyncState {
    object Idle : SyncState()
    object Syncing : SyncState()
    object Synced : SyncState()
    object Error : SyncState()
}
