package com.example.myapplication.model

import androidx.annotation.DrawableRes

data class Course(
    val id: String,
    val title: String,
    val description: String,
    val imageUrl: String? = null,
    @DrawableRes val iconRes: Int? = null,
    val units: List<CourseUnit> = emptyList(),
    val trending: Boolean = false,
    val isNew: Boolean = false,
    val progress: Float = 0f,
    val gradientStart: Long = 0xFF7C3AED,
    val gradientEnd: Long = 0xFF4F46E5,
    val tag: String = ""
)

data class CourseUnit(
    val id: String,
    val title: String,
    val lessons: List<Lesson> = emptyList(),
    val isCompleted: Boolean = false
)

data class Lesson(
    val id: String,
    val title: String,
    val type: LessonType,
    val durationMinutes: Int,
    val content: List<LessonContent> = emptyList(),
    val isCompleted: Boolean = false,
    val xpReward: Int = 10,
    val isLocked: Boolean = false
)

enum class LessonType {
    CONTENT, QUIZ, CODE
}

sealed class LessonContent {
    data class Text(val text: String, val isHeader: Boolean = false) : LessonContent()
    data class Image(val imageUrl: String, val caption: String? = null) : LessonContent()
    data class Animation(val animationRes: String) : LessonContent()
    data class CodeSnippet(
        val code: String,
        val language: String = "python",
        val caption: String? = null
    ) : LessonContent()
    data class Quiz(
        val question: String,
        val options: List<String>,
        val correctAnswerIndex: Int,
        val explanation: String? = null
    ) : LessonContent()
}
