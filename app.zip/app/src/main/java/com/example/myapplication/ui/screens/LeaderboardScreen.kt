package com.example.myapplication.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.*

data class LeaderboardEntry(
    val rank: Int, val name: String, val xp: Int,
    val streak: Int, val avatar: String, val isCurrentUser: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardScreen(currentXp: Int = 0) {
    var selectedPeriod by remember { mutableStateOf(0) } // 0=Weekly, 1=All-Time

    val entries = remember(selectedPeriod) {
        val base = listOf(
            LeaderboardEntry(1, "CodeMaster99", if (selectedPeriod==0) 2840 else 18500, 42, "🥷"),
            LeaderboardEntry(2, "PythonQueen", if (selectedPeriod==0) 2650 else 15200, 31, "👩‍💻"),
            LeaderboardEntry(3, "NightCoder", if (selectedPeriod==0) 2400 else 12800, 28, "🦉"),
            LeaderboardEntry(4, "AlgoKing", if (selectedPeriod==0) 2100 else 10500, 21, "👑"),
            LeaderboardEntry(5, "You 🎯", if (selectedPeriod==0) currentXp else currentXp * 3, 1, "🧑‍💻", isCurrentUser = true),
            LeaderboardEntry(6, "DataNerd", if (selectedPeriod==0) 1800 else 9200, 14, "📊"),
            LeaderboardEntry(7, "FlutterFly", if (selectedPeriod==0) 1650 else 8100, 12, "🦋"),
            LeaderboardEntry(8, "JSWizard", if (selectedPeriod==0) 1500 else 7800, 9, "⚡"),
            LeaderboardEntry(9, "ByteBuilder", if (selectedPeriod==0) 1350 else 6500, 7, "🔧"),
            LeaderboardEntry(10, "LoopLearner", if (selectedPeriod==0) 1200 else 5900, 5, "🔄"),
        ).sortedByDescending { it.xp }.mapIndexed { i, e -> e.copy(rank = i + 1) }
        base
    }

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            TopAppBar(
                title = { Text("Leaderboard 🏆", fontWeight = FontWeight.ExtraBold, color = TextPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize().background(DeepSpace),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Period toggle
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(SurfaceDark),
                ) {
                    listOf("This Week", "All Time").forEachIndexed { i, label ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (selectedPeriod == i)
                                        Brush.horizontalGradient(listOf(ElectricViolet, NeonCyan))
                                    else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                )
                                .clickable { selectedPeriod = i }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                label,
                                color = if (selectedPeriod == i) Color.White else TextMuted,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // Top 3 podium
            item {
                val top3 = entries.take(3)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF1A1035), SurfaceDark)))
                        .padding(20.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        if (top3.size > 1) PodiumItem(top3[1], 80.dp)
                        if (top3.isNotEmpty()) PodiumItem(top3[0], 100.dp)
                        if (top3.size > 2) PodiumItem(top3[2], 60.dp)
                    }
                }
            }

            // Rest of list
            itemsIndexed(entries.drop(3)) { idx, entry ->
                LeaderboardRow(entry = entry, animDelay = idx * 60)
            }
        }
    }
}

@Composable
fun PodiumItem(entry: LeaderboardEntry, height: androidx.compose.ui.unit.Dp) {
    val medalEmoji = when (entry.rank) { 1 -> "🥇"; 2 -> "🥈"; else -> "🥉" }
    val medalColor = when (entry.rank) { 1 -> Color(0xFFF59E0B); 2 -> Color(0xFF94A3B8); else -> Color(0xFFCD7C2F) }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(entry.avatar, fontSize = if (entry.rank == 1) 32.sp else 24.sp)
        Spacer(Modifier.height(4.dp))
        Text(entry.name.take(8), fontSize = 10.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
        Text("${entry.xp} XP", fontSize = 10.sp, color = XpGold, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .width(70.dp)
                .height(height)
                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                .background(medalColor.copy(alpha = 0.25f))
                .border(1.dp, medalColor.copy(alpha = 0.4f), RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(medalEmoji, fontSize = 24.sp)
        }
    }
}

@Composable
fun LeaderboardRow(entry: LeaderboardEntry, animDelay: Int = 0) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(animDelay.toLong())
        visible = true
    }

    androidx.compose.animation.AnimatedVisibility(
        visible = visible,
        enter = androidx.compose.animation.slideInHorizontally { -it } + androidx.compose.animation.fadeIn()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (entry.isCurrentUser)
                    ElectricViolet.copy(0.15f) else SurfaceDark
            ),
            border = if (entry.isCurrentUser)
                BorderStroke(1.dp, ElectricViolet.copy(0.4f)) else null
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "#${entry.rank}",
                    color = if (entry.rank <= 3) XpGold else TextMuted,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    modifier = Modifier.width(36.dp)
                )
                Text(entry.avatar, fontSize = 28.sp)
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(entry.name, fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 14.sp)
                    Text("🔥 ${entry.streak} day streak", color = StreakOrange, fontSize = 11.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${entry.xp}", fontWeight = FontWeight.ExtraBold, color = XpGold, fontSize = 16.sp)
                    Text("XP", color = TextMuted, fontSize = 10.sp)
                }
            }
        }
    }
}
