package com.example.myapplication.model

data class UserProgress(
    val xp: Int = 0,
    val level: Int = 1,
    val streak: Int = 1,
    val heartsLeft: Int = 5,
    val maxHearts: Int = 5,
    val dailyXpGoal: Int = 50,
    val dailyXpEarned: Int = 0,
    val completedLessonIds: Set<String> = emptySet(),
    val totalLessonsCompleted: Int = 0
) {
    /** XP is cumulative: level 1 ends at 100, level 2 at 200, and so on. */
    val xpToNextLevel: Int get() = level * 100
    val levelProgress: Float
        get() {
            val xpAtLevelStart = (level - 1).coerceAtLeast(0) * 100
            return ((xp - xpAtLevelStart).toFloat() / 100f).coerceIn(0f, 1f)
        }
    val dailyGoalProgress: Float get() = (dailyXpEarned.toFloat() / dailyXpGoal).coerceAtMost(1f)
    val hasFullHearts: Boolean get() = heartsLeft == maxHearts
}

data class XpGain(
    val amount: Int,
    val reason: String = "Correct Answer!"
)
