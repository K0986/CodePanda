package com.example.myapplication.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.myapplication.model.Lesson
import com.example.myapplication.model.LessonContent
import com.example.myapplication.ui.components.GlowButton
import com.example.myapplication.ui.components.HeartBar
import com.example.myapplication.ui.components.XpPopup
import com.example.myapplication.ui.theme.*
import com.example.myapplication.viewmodel.LessonViewModel
import com.example.myapplication.viewmodel.UserProgressViewModel
import androidx.compose.ui.layout.ContentScale
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonScreen(
    lesson: Lesson,
    onExit: () -> Unit,
    onComplete: () -> Unit,
    lessonViewModel: LessonViewModel = viewModel(),
    progressViewModel: UserProgressViewModel = viewModel()
) {
    var currentContentIndex by remember { mutableStateOf(0) }
    var showAiDialog by remember { mutableStateOf(false) }
    val aiResponse by lessonViewModel.aiResponse.collectAsState()
    val isAiLoading by lessonViewModel.isLoading.collectAsState()
    val userProgress by progressViewModel.progress.collectAsState()
    val xpGainEvent by progressViewModel.xpGainEvent.collectAsState()
    val heartLostEvent by progressViewModel.heartLostEvent.collectAsState()

    val currentContent = lesson.content.getOrNull(currentContentIndex)
    val progress = (currentContentIndex + 1).toFloat() / lesson.content.size.coerceAtLeast(1)
    val isLastContent = currentContentIndex >= lesson.content.size - 1

    // Track if current quiz was answered correctly (to enable Continue button)
    var quizAnswered by remember { mutableStateOf(false) }
    var quizCorrect by remember { mutableStateOf(false) }
    var completionSent by remember(lesson.id) { mutableStateOf(false) }

    // Reset quiz state when slide changes
    LaunchedEffect(currentContentIndex) {
        quizAnswered = false
        quizCorrect = false
    }

    val isQuiz = currentContent is LessonContent.Quiz
    val canContinue = !isQuiz || quizAnswered

    Scaffold(
        containerColor = DeepSpace,
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Text(
                            lesson.title,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onExit) {
                            Icon(Icons.Default.Close, contentDescription = "Exit", tint = TextSecondary)
                        }
                    },
                    actions = {
                        // Hearts display
                        HeartBar(
                            heartsLeft = userProgress.heartsLeft,
                            maxHearts = userProgress.maxHearts,
                            heartLost = heartLostEvent,
                            onHeartLostAnimationDone = { progressViewModel.clearHeartLostEvent() }
                        )
                        Spacer(Modifier.width(4.dp))
                        // AI tutor button
                        Surface(
                            onClick = { showAiDialog = true },
                            shape = RoundedCornerShape(12.dp),
                            color = ElectricViolet.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, ElectricViolet.copy(alpha = 0.5f)),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.AutoAwesome,
                                    contentDescription = "Ask AI",
                                    tint = VioletLight,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    "AI",
                                    color = VioletLight,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = SurfaceDark)
                )

                // Glowing progress bar
                val animProgress by animateFloatAsState(
                    targetValue = progress,
                    animationSpec = tween(400),
                    label = "progress"
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .background(SurfaceVariantDark)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animProgress)
                            .height(6.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(ElectricViolet, NeonCyan)
                                )
                            )
                    )
                }
            }
        },
        bottomBar = {
            Surface(
                color = SurfaceDark,
                tonalElevation = 0.dp
            ) {
                GlowButton(
                    text = when {
                        isQuiz && !quizAnswered -> "SELECT AN ANSWER"
                        isLastContent -> "FINISH LESSON 🏆"
                        else -> "CONTINUE →"
                    },
                    enabled = canContinue && !completionSent,
                    onClick = {
                        if (currentContentIndex < lesson.content.size - 1) {
                            currentContentIndex++
                        } else if (!completionSent) {
                            completionSent = true
                            progressViewModel.completeLesson(lesson.id, lesson.xpReward)
                            onComplete()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize()) {
            // Main content
            Box(
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
            ) {
                AnimatedContent(
                    targetState = currentContent,
                    transitionSpec = {
                        (slideInHorizontally { it } + fadeIn()) togetherWith
                                (slideOutHorizontally { -it } + fadeOut())
                    },
                    label = "ContentTransition"
                ) { content ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        when (content) {
                            is LessonContent.Text -> GameTextContentView(content)
                            is LessonContent.CodeSnippet -> CodeSnippetView(content)
                            is LessonContent.Quiz -> GameQuizContentView(
                                content = content,
                                onAnswered = { correct ->
                                    quizAnswered = true
                                    quizCorrect = correct
                                    if (correct) {
                                        progressViewModel.addXp(10, "Correct Answer!")
                                    } else {
                                        progressViewModel.loseHeart()
                                    }
                                }
                            )
                            is LessonContent.Image -> Column(
                                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AsyncImage(
                                    model = content.imageUrl,
                                    contentDescription = content.caption,
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)),
                                    contentScale = ContentScale.Crop
                                )
                                content.caption?.let {
                                    Text(it, color = TextSecondary, modifier = Modifier.padding(12.dp))
                                }
                            }
                            is LessonContent.Animation -> AnimatedConceptCard(content.animationRes)
                            else -> {}
                        }
                    }
                }
            }

            // XP Pop-up overlay
            if (xpGainEvent != null) {
                XpPopup(
                    xpGain = xpGainEvent,
                    onDismiss = { progressViewModel.clearXpGainEvent() }
                )
            }

            // AI Dialog
            if (showAiDialog) {
                GameAiTutorDialog(
                    lessonTitle = lesson.title,
                    response = aiResponse,
                    isLoading = isAiLoading,
                    onAsk = { lessonViewModel.askAI(lesson.title, it) },
                    onDismiss = {
                        showAiDialog = false
                        lessonViewModel.clearAIResponse()
                    }
                )
            }
        }
    }
}

@Composable
private fun AnimatedConceptCard(animationRes: String) {
    val transition = rememberInfiniteTransition(label = "lessonIllustration")
    val bob by transition.animateFloat(
        initialValue = -8f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(1200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "bob"
    )
    val pulse by transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(900, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "pulse"
    )
    val (emoji, title, body) = when (animationRes) {
        "function_recipe" -> Triple("🧩", "Reusable recipe", "Ingredients in → useful result out")
        "collections" -> Triple("🧺", "Organize your data", "Lists, dictionaries, and sets each have a job")
        "modules" -> Triple("📚", "Borrow a superpower", "Import trusted tools instead of rebuilding them")
        else -> Triple("🐍", "Python in motion", "Small steps become powerful programs")
    }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(180.dp)
                .graphicsLayer { translationY = bob; scaleX = pulse; scaleY = pulse }
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(ElectricViolet.copy(0.45f), SurfaceDark))),
            contentAlignment = Alignment.Center
        ) { Text(emoji, fontSize = 78.sp) }
        Spacer(Modifier.height(24.dp))
        Text(title, color = TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Spacer(Modifier.height(8.dp))
        Text(body, color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}

@Composable
fun GameTextContentView(content: LessonContent.Text) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Top
    ) {
        if (content.isHeader) {
            Text(
                text = content.text,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary,
                modifier = Modifier.padding(bottom = 24.dp)
            )
        } else {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = content.text,
                    style = MaterialTheme.typography.bodyLarge,
                    lineHeight = 28.sp,
                    color = TextPrimary,
                    modifier = Modifier.padding(20.dp)
                )
            }
        }
    }
}

@Composable
fun CodeSnippetView(content: LessonContent.CodeSnippet) {
    Column(modifier = Modifier.fillMaxWidth()) {
        content.caption?.let { caption ->
            Text(
                caption,
                style = MaterialTheme.typography.labelLarge,
                color = NeonCyan,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1117)),
            border = BorderStroke(1.dp, Color(0xFF30363D)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Language label
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF7C3AED).copy(alpha = 0.3f)
                    ) {
                        Text(
                            content.language.uppercase(),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = VioletLight,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Text("▶ Run", fontSize = 11.sp, color = Color(0xFF4CAF50), fontWeight = FontWeight.Bold)
                }

                // Syntax-colored code (simplified)
                val lines = content.code.lines()
                lines.forEach { line ->
                    CodeLine(line)
                }
            }
        }
    }
}

@Composable
fun CodeLine(line: String) {
    val commentColor = Color(0xFF6A9955)
    val keywordColor = Color(0xFF569CD6)
    val stringColor = Color(0xFFCE9178)
    val funcColor = Color(0xFFDCDCAA)
    val defaultColor = Color(0xFFD4D4D4)

    val isComment = line.trim().startsWith("#")
    val color = when {
        isComment -> commentColor
        line.contains("print") || line.contains("input") -> funcColor
        line.contains("if ") || line.contains("else") || line.contains("for ") ||
                line.contains("while ") || line.contains("def ") -> keywordColor
        line.contains("\"") || line.contains("'") -> stringColor
        else -> defaultColor
    }

    Text(
        text = line,
        fontFamily = FontFamily.Monospace,
        fontSize = 13.sp,
        color = color,
        lineHeight = 22.sp
    )
}

@Composable
fun GameQuizContentView(
    content: LessonContent.Quiz,
    onAnswered: (Boolean) -> Unit
) {
    var selectedOption by remember { mutableStateOf(-1) }
    var showFeedback by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Question header
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = ElectricViolet.copy(alpha = 0.12f)
            ),
            border = BorderStroke(1.dp, ElectricViolet.copy(alpha = 0.3f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                Text("💬", fontSize = 24.sp)
                Spacer(Modifier.width(12.dp))
                Text(
                    text = content.question,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // Answer options with staggered animation
        content.options.forEachIndexed { index, option ->
            var itemVisible by remember { mutableStateOf(false) }
            LaunchedEffect(Unit) {
                delay(index * 100L)
                itemVisible = true
            }

            AnimatedVisibility(
                visible = itemVisible,
                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn()
            ) {
                val isSelected = selectedOption == index
                val isCorrect = index == content.correctAnswerIndex
                val containerColor = when {
                    !showFeedback && isSelected -> ElectricViolet.copy(alpha = 0.2f)
                    showFeedback && isCorrect -> CorrectGreenSurface
                    showFeedback && isSelected && !isCorrect -> WrongRedSurface
                    else -> SurfaceDark
                }
                val borderColor = when {
                    !showFeedback && isSelected -> ElectricViolet
                    showFeedback && isCorrect -> CorrectGreen
                    showFeedback && isSelected && !isCorrect -> WrongRed
                    else -> SurfaceVariantDark
                }

                // Bounce scale on correct answer
                val scale by animateFloatAsState(
                    targetValue = if (showFeedback && isCorrect && isSelected) 1.03f else 1f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "answerScale"
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .scale(scale)
                        .selectable(
                            selected = isSelected,
                            onClick = {
                                if (!showFeedback) {
                                    selectedOption = index
                                    showFeedback = true
                                    onAnswered(index == content.correctAnswerIndex)
                                }
                            }
                        ),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.5.dp, borderColor),
                    colors = CardDefaults.cardColors(containerColor = containerColor)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Option label
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(borderColor.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                ('A' + index).toString(),
                                color = borderColor,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(Modifier.width(14.dp))
                        Text(
                            text = option,
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (showFeedback && isCorrect) Text("✅", fontSize = 18.sp)
                        else if (showFeedback && isSelected && !isCorrect) Text("❌", fontSize = 18.sp)
                    }
                }
            }
        }

        // Explanation
        AnimatedVisibility(
            visible = showFeedback && content.explanation != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn()
        ) {
            content.explanation?.let { explanation ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedOption == content.correctAnswerIndex)
                            CorrectGreenSurface else WrongRedSurface
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp)) {
                        Text(
                            if (selectedOption == content.correctAnswerIndex) "💡" else "💪",
                            fontSize = 20.sp
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = explanation,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GameAiTutorDialog(
    lessonTitle: String,
    response: String?,
    isLoading: Boolean,
    onAsk: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var question by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(24.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(VioletLight, ElectricViolet))),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🤖", fontSize = 18.sp)
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(
                        "AI Tutor",
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontSize = 16.sp
                    )
                    Text(
                        lessonTitle,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        },
        text = {
            Column {
                if (response != null) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = SurfaceVariantDark)
                    ) {
                        Text(
                            text = response,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                } else if (isLoading) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        CircularProgressIndicator(color = ElectricViolet)
                        Spacer(Modifier.height(8.dp))
                        Text("Thinking... 🧠", color = TextSecondary, fontSize = 13.sp)
                    }
                } else {
                    OutlinedTextField(
                        value = question,
                        onValueChange = { question = it },
                        placeholder = {
                            Text("e.g. What is a variable?", color = TextMuted)
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricViolet,
                            unfocusedBorderColor = SurfaceVariantDark,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = ElectricViolet
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            if (response == null && !isLoading) {
                GlowButton(
                    text = "✨ ASK AI",
                    onClick = { if (question.isNotBlank()) onAsk(question) },
                    enabled = question.isNotBlank()
                )
            } else {
                GlowButton(
                    text = "CLOSE",
                    onClick = onDismiss,
                    gradientColors = listOf(Color(0xFF4B4B6B), Color(0xFF3A3A5C))
                )
            }
        }
    )
}
