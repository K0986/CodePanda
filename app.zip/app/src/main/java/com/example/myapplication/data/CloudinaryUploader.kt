package com.example.myapplication.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

object CloudinaryUploader {

    private const val CLOUD_NAME   = "lgaaeebm"
    private const val UPLOAD_PRESET = "python_hero_profiles"
    private const val UPLOAD_URL   = "https://api.cloudinary.com/v1_1/$CLOUD_NAME/image/upload"

    /**
     * Uploads a photo to Cloudinary using an unsigned upload preset.
     * No API key or secret is required — safe to call directly from Android.
     *
     * @param context  App context for content resolver
     * @param imageUri URI selected from the gallery / camera
     * @param userId   Firebase UID used as the public_id (organizes photos per user)
     * @return Secure HTTPS URL of the uploaded image, or null on failure
     */
    suspend fun uploadProfilePhoto(
        context: Context,
        imageUri: Uri,
        userId: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val imageBytes = context.contentResolver
                .openInputStream(imageUri)
                ?.readBytes()
                ?: return@withContext Result.failure(Exception("Cannot read image"))

            val boundary = "----AndroidBoundary${System.currentTimeMillis()}"
            val url = URL(UPLOAD_URL)
            val conn = url.openConnection() as HttpURLConnection
            conn.apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 30_000
                readTimeout = 60_000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }

            DataOutputStream(conn.outputStream).use { out ->
                // ── Field: upload_preset ────────────────────────────────
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"upload_preset\"\r\n\r\n")
                out.writeBytes("$UPLOAD_PRESET\r\n")

                // ── Field: public_id (organizes in Cloudinary as profile_photos/{uid}) ──
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"public_id\"\r\n\r\n")
                out.writeBytes("profile_photos/$userId\r\n")

                // ── File: image bytes ───────────────────────────────────
                out.writeBytes("--$boundary\r\n")
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"profile.jpg\"\r\n")
                out.writeBytes("Content-Type: image/jpeg\r\n\r\n")
                out.write(imageBytes)
                out.writeBytes("\r\n")
                out.writeBytes("--$boundary--\r\n")
            }

            val responseCode = conn.responseCode
            if (responseCode != 200) {
                val error = conn.errorStream?.bufferedReader()?.readText() ?: "Unknown error"
                return@withContext Result.failure(Exception("Upload failed ($responseCode): $error"))
            }

            val json = JSONObject(conn.inputStream.bufferedReader().readText())
            val secureUrl = json.optString("secure_url")
            if (secureUrl.isBlank()) {
                return@withContext Result.failure(Exception("No URL returned from Cloudinary"))
            }

            Result.success(secureUrl)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
